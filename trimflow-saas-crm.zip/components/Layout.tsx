
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  Activity, 
  Settings, 
  Scissors,
  LogOut,
  Menu,
  Bell,
  Search,
  Sparkles,
  Moon,
  Sun,
  X,
  CheckCircle,
  Clock
} from 'lucide-react';
import { BusinessConfig, UserAccount } from '../types';

// --- COMPONENTS FOR MODALS AND DROPDOWNS ---

const NewAppointmentModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl w-full max-md overflow-hidden border border-zinc-200 dark:border-zinc-800">
        <div className="px-6 py-4 border-b border-zinc-100 dark:border-zinc-800 flex justify-between items-center bg-zinc-50 dark:bg-zinc-900/50">
          <h3 className="font-bold text-lg text-zinc-900 dark:text-zinc-100 flex items-center">
            <Sparkles size={18} className="mr-2 text-primary-500" />
            Novo Agendamento
          </h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase mb-1">Cliente</label>
            <input type="text" placeholder="Buscar cliente..." className="w-full px-3 py-2 border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" />
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div>
                <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase mb-1">Data</label>
                <input type="date" className="w-full px-3 py-2 border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" />
             </div>
             <div>
                <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase mb-1">Hora</label>
                <input type="time" className="w-full px-3 py-2 border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" />
             </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase mb-1">Serviço</label>
            <select className="w-full px-3 py-2 border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm">
              <option>Corte Degradê</option>
              <option>Barba e Bigode</option>
              <option>Combo Completo</option>
            </select>
          </div>
          
          <button 
            onClick={onClose}
            className="w-full mt-4 bg-primary-600 hover:bg-primary-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-primary-500/20 transition-all active:scale-[0.98]"
          >
            Confirmar Agendamento
          </button>
        </div>
      </div>
    </div>
  );
};

const NotificationDropdown = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  if (!isOpen) return null;

  return (
    <div className="absolute right-0 top-12 w-80 bg-white dark:bg-zinc-900 rounded-xl shadow-xl border border-zinc-200 dark:border-zinc-800 z-50 animate-in fade-in zoom-in-95 duration-100 overflow-hidden">
       <div className="px-4 py-3 border-b border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50 flex justify-between items-center">
          <span className="font-bold text-sm text-zinc-800 dark:text-zinc-100">Notificações</span>
          <button className="text-xs text-primary-600 hover:text-primary-700 font-medium">Marcar lidas</button>
       </div>
       <div className="max-h-64 overflow-y-auto">
          <div className="p-3 border-b border-zinc-100 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors cursor-pointer">
             <div className="flex items-start">
                <div className="mt-1 w-2 h-2 rounded-full bg-primary-500 mr-2 flex-shrink-0"></div>
                <div>
                   <p className="text-sm text-zinc-800 dark:text-zinc-200 font-medium">Novo agendamento confirmado</p>
                   <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Roberto Almeida agendou para hoje às 14:00.</p>
                   <p className="text-[10px] text-zinc-400 mt-1">Há 5 min</p>
                </div>
             </div>
          </div>
       </div>
    </div>
  );
};

const SidebarItem = ({ to, icon: Icon, label, active, badge }: { to: string, icon: any, label: string, active: boolean, badge?: string }) => (
  <Link 
    to={to} 
    className={`group flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 mb-1 ${
      active 
        ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 shadow-lg' 
        : 'text-zinc-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-900 dark:hover:text-zinc-100'
    }`}
  >
    <div className="flex items-center space-x-3">
      <Icon size={20} className={`transition-colors ${active ? 'text-primary-400 dark:text-primary-600' : 'group-hover:text-zinc-900 dark:group-hover:text-white'}`} />
      <span className="font-medium text-sm">{label}</span>
    </div>
    {badge && (
      <span className="bg-primary-500/20 dark:bg-primary-900/30 text-primary-700 dark:text-primary-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-primary-500/20">
        {badge}
      </span>
    )}
  </Link>
);

interface LayoutProps {
  children: React.ReactNode;
  onLogout: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, onLogout }) => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);

  const [shopName, setShopName] = useState('Trim Flow');
  const [user, setUser] = useState<UserAccount | null>(null);

  useEffect(() => {
    const session = localStorage.getItem('trimflow_session');
    if (session) {
      const u: UserAccount = JSON.parse(session);
      setUser(u);
      const configStr = localStorage.getItem(`trimflow_config_${u.id}`);
      if (configStr) {
        const config: BusinessConfig = JSON.parse(configStr);
        if (config.shopName) setShopName(config.shopName);
      }
    }
  }, []);

  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDarkMode]);

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="flex h-screen bg-zinc-50 dark:bg-zinc-950 overflow-hidden font-sans transition-colors duration-300">
      <NewAppointmentModal isOpen={isAppointmentModalOpen} onClose={() => setIsAppointmentModalOpen(false)} />

      <aside className="hidden md:flex w-72 flex-col bg-white dark:bg-zinc-950 border-r border-zinc-200 dark:border-zinc-800 transition-colors duration-300">
        <div className="flex items-center px-6 h-20 border-b border-zinc-100 dark:border-zinc-800/50">
          <div>
            <span className="text-xl font-bold text-zinc-900 dark:text-white tracking-tight block leading-none font-serif">{shopName}</span>
            <span className="text-[10px] text-zinc-400 dark:text-zinc-500 font-medium uppercase tracking-wider mt-1 block">Powered by Trim Flow</span>
          </div>
        </div>
        
        <div className="px-4 py-6">
          <p className="text-xs font-bold text-zinc-400 dark:text-zinc-600 uppercase tracking-wider mb-4 px-2">Principal</p>
          <nav className="space-y-1">
            <SidebarItem to="/" icon={LayoutDashboard} label="Dashboard" active={isActive('/')} />
            <SidebarItem to="/appointments" icon={Calendar} label="Agenda Inteligente" active={isActive('/appointments')} />
            <SidebarItem to="/clients" icon={Users} label="Base de Clientes" active={isActive('/clients')} />
          </nav>

          <p className="text-xs font-bold text-zinc-400 dark:text-zinc-600 uppercase tracking-wider mt-8 mb-4 px-2">Estratégia</p>
          <nav className="space-y-1">
            <SidebarItem to="/recovery" icon={Activity} label="Recuperação (IA)" active={isActive('/recovery')} badge="R$ 4.2k" />
            <SidebarItem to="/services" icon={Scissors} label="Menu de Serviços" active={isActive('/services')} />
          </nav>
          
          <p className="text-xs font-bold text-zinc-400 dark:text-zinc-600 uppercase tracking-wider mt-8 mb-4 px-2">Sistema</p>
          <nav className="space-y-1">
            <SidebarItem to="/settings" icon={Settings} label="Configurações" active={isActive('/settings')} />
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-zinc-100 dark:border-zinc-800">
          <div className="bg-zinc-50 dark:bg-zinc-900 rounded-xl p-4 flex items-center space-x-3 border border-zinc-100 dark:border-zinc-800">
             <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-zinc-800 to-zinc-600 flex items-center justify-center text-white font-bold text-xs">
               {user?.name.substring(0,2).toUpperCase() || 'JS'}
             </div>
             <div className="flex-1 overflow-hidden">
               <p className="text-sm font-medium text-zinc-900 dark:text-white truncate">{user?.name || 'Gestor'}</p>
               <p className="text-[10px] text-zinc-500 truncate uppercase tracking-tighter">Sócio Proprietário</p>
             </div>
             <button onClick={onLogout} className="text-zinc-400 hover:text-red-500 transition-colors">
               <LogOut size={16} />
             </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-20 bg-white/80 dark:bg-zinc-950/80 backdrop-blur-md border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between px-8 z-10 sticky top-0 transition-colors duration-300">
          <div className="flex items-center md:hidden">
            <button className="text-zinc-500 hover:text-zinc-800 p-2 -ml-2" onClick={() => setMobileMenuOpen(true)}>
              <Menu size={24} />
            </button>
          </div>

          <div className="hidden md:flex items-center bg-zinc-50 dark:bg-zinc-900 rounded-full px-4 py-2.5 w-96 border border-zinc-200 dark:border-zinc-800">
            <Search size={18} className="text-zinc-400 mr-3" />
            <input type="text" placeholder="Buscar..." className="bg-transparent border-none outline-none text-sm text-zinc-700 dark:text-zinc-200 w-full" />
          </div>

          <div className="flex items-center space-x-4 ml-auto">
            <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-2 text-zinc-400 hover:text-zinc-600 rounded-full hover:bg-zinc-100">
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <div className="relative">
              <button onClick={() => setIsNotificationOpen(!isNotificationOpen)} className="p-2 text-zinc-400 hover:text-zinc-600 rounded-full hover:bg-zinc-100">
                <Bell size={20} />
              </button>
              <NotificationDropdown isOpen={isNotificationOpen} onClose={() => setIsNotificationOpen(false)} />
            </div>
            <button onClick={() => setIsAppointmentModalOpen(true)} className="hidden md:flex items-center space-x-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 px-4 py-2 rounded-lg text-sm font-medium transition-all hover:scale-105 active:scale-95">
              <Sparkles size={16} />
              <span>Agendar</span>
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-auto bg-zinc-50/50 dark:bg-zinc-950 transition-colors duration-300">
          <div className="max-w-7xl mx-auto p-6 md:p-10">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

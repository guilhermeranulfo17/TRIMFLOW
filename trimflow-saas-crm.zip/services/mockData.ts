
import { Client, RiskLevel, TrendDirection, Appointment, AppointmentStatus, Service, DashboardStats } from '../types';

// Mock Services - Mantidos apenas como base de catálogo inicial
export const MOCK_SERVICES: Service[] = [
  { id: '1', name: 'Corte Degradê', price: 0, duration_minutes: 30, category: 'Cabelo' },
  { id: '2', name: 'Barba Modelada', price: 0, duration_minutes: 30, category: 'Barba' },
  { id: '3', name: 'Combo Completo', price: 0, duration_minutes: 60, category: 'Combo' },
];

// Mock Clients - Resetado para lista vazia
export const MOCK_CLIENTS: Client[] = [];

// Mock Appointments - Resetado para lista vazia
export const MOCK_APPOINTMENTS: Appointment[] = [];

// Mock Stats - Tudo zerado para o primeiro acesso
export const MOCK_STATS: DashboardStats = {
  revenue_today: 0,
  revenue_month: 0,
  appointments_today: 0,
  active_clients: 0,
  risk_clients_critical: 0
};

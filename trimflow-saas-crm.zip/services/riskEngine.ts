
import { Client, RiskLevel, TrendDirection } from '../types';

/**
 * Motor de Risco Calibrado para o Início do Sistema.
 * Trata casos de novos clientes (zero visitas) de forma segura.
 */
export const calculateClientRisk = (client: Client): Client => {
  const today = new Date();
  const lastVisitDate = client.last_visit ? new Date(client.last_visit) : today;
  
  const diffTime = Math.abs(today.getTime() - lastVisitDate.getTime());
  const daysSinceLastVisit = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  
  // Frequência mínima de 1 dia para evitar divisão por zero
  const avgFrequency = Math.max(client.average_frequency_days || 30, 1);
  
  const riskPercent = (daysSinceLastVisit / avgFrequency) * 100;
  
  let riskLevel = RiskLevel.None;
  if (client.total_visits > 0) {
    if (riskPercent < 70) riskLevel = RiskLevel.None;
    else if (riskPercent < 90) riskLevel = RiskLevel.Light;
    else if (riskPercent < 110) riskLevel = RiskLevel.Moderate;
    else riskLevel = RiskLevel.Critical;
  }
  
  let trend = TrendDirection.Stable;
  const previousRiskPercent = client.risk_percentage || 0;
  
  if (client.total_visits > 0) {
    if (Math.abs(riskPercent - previousRiskPercent) < 5) trend = TrendDirection.Stable;
    else if (riskPercent > previousRiskPercent) trend = TrendDirection.Declining;
    else trend = TrendDirection.Improving;
  }

  const isInactive = client.total_visits > 0 && daysSinceLastVisit > (avgFrequency * 3);

  return {
    ...client,
    last_visit: lastVisitDate.toISOString().split('T')[0],
    days_since_last_visit: daysSinceLastVisit,
    risk_level: riskLevel,
    risk_percentage: parseFloat(riskPercent.toFixed(1)),
    trend_direction: trend,
    is_inactive: isInactive
  };
};

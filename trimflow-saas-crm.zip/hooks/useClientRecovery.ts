
import { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Client } from '../types';

export const useClientRecovery = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiMessage, setAiMessage] = useState('');

  const generateRecoveryMessage = async (client: Client, shopName: string = 'Trim Flow', strategy: 'friendly' | 'offer' | 'vip' = 'friendly') => {
    setIsGenerating(true);
    setAiMessage('');

    try {
      // Initialize the SDK with the environment API key
      // GUIDELINE: Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const prompt = `
        Atue como o dono da barbearia "${shopName}".
        Escreva uma mensagem de WhatsApp para o cliente ${client.name}.
        
        DADOS DO CLIENTE:
        - Última visita: há ${client.days_since_last_visit} dias.
        - Status de Risco: ${client.risk_level}.
        - Ticket Médio: R$ ${client.average_service_value}.
        - Total de visitas: ${client.total_visits}.

        ESTRATÉGIA ESPECÍFICA:
        - Tom: ${strategy === 'friendly' ? 'Amigável e Casual (apenas lembrete)' : strategy === 'offer' ? 'Persuasivo com Oferta (foco em benefício/desconto)' : 'Exclusivo e VIP (foco em status e experiência)'}
        
        REGRAS DE OURO:
        - Identifique-se ou mencione a barbearia "${shopName}" naturalmente.
        - Use o primeiro nome do cliente.
        - Seja breve (máximo 4 linhas).
        - Use gírias leves de barbearia ("degradê", "trato no visual", "alinhar", "na régua").
        - Termine sempre com uma pergunta instigando o agendamento.
        - Não pareça um robô. Pareça um amigo profissional mandando uma mensagem rápida.

        Saída: Apenas o texto da mensagem, sem aspas.
      `;
      
      // GUIDELINE: Use gemini-3-flash-preview for basic text tasks
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      
      // GUIDELINE: Access the text directly via the .text property (not a method)
      setAiMessage(response.text || '');
    } catch (error) {
      console.error("AI Error", error);
      setAiMessage("Erro ao gerar mensagem. Tente novamente.");
    } finally {
      setIsGenerating(false);
    }
  };

  return { 
    aiMessage, 
    setAiMessage, 
    isGenerating, 
    generateRecoveryMessage 
  };
};
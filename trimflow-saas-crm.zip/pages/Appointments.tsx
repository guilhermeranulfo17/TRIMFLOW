
import React, { useState, useMemo, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  Plus, 
  Calendar as CalendarIcon, 
  Search, 
  UserPlus, 
  Users, 
  X, 
  CheckCircle2,
  TrendingUp,
  AlertCircle,
  Bell,
  AlertTriangle
} from 'lucide-react';
import { MOCK_CLIENTS, MOCK_SERVICES } from '../services/mockData';
import { Appointment, AppointmentStatus, BusinessConfig, Client, RiskLevel, TrendDirection } from '../types';
import { calculateClientRisk } from '../services/riskEngine';

type ViewType = 'day' | 'week' | 'month';

export const Appointments = () => {
  const [view, setView] = useState<ViewType>('week');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [appointmentStep, setAppointmentStep] = useState<'type' | 'details'>('type');
  const [clientType, setClientType] = useState<'base' | 'new' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  const bizConfig: BusinessConfig = JSON.parse(localStorage.getItem('trendflow_config') || '{}');

  // CENTRAL DE DADOS (Célula de verdade do app)
  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem('trendflow_clients');
    return saved ? JSON.parse(saved) : MOCK_CLIENTS;
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const saved = localStorage.getItem('trendflow_appointments');
    return saved ? JSON.parse(saved) : [];
  });

  const [formData, setFormData] = useState({
    clientId: '',
    clientName: '',
    phone: '',
    serviceId: '',
    date: new Date().toISOString().split('T')[0],
    time: '09:00'
  });

  const DAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'];
  
  const HOURS = useMemo(() => {
    const start = parseInt(bizConfig.openingTime?.split(':')[0] || '8');
    const end = parseInt(bizConfig.closingTime?.split(':')[0] || '20');
    return Array.from({ length: end - start + 1 }, (_, i) => i + start);
  }, [bizConfig]);

  const occupancyStats = useMemo(() => {
    const dateStr = selectedDate.toISOString().split('T')[0];
    const dayApps = appointments.filter(a => a.appointment_date === dateStr);
    const totalScheduledMinutes = dayApps.reduce((acc, curr) => acc + (curr.duration_minutes || 40), 0);
    const startH = parseInt(bizConfig.openingTime?.split(':')[0] || '8');
    const endH = parseInt(bizConfig.closingTime?.split(':')[0] || '20');
    const totalAvailableMinutes = (endH - startH) * 60;
    return {
      rate: totalAvailableMinutes > 0 ? Math.round((totalScheduledMinutes / totalAvailableMinutes) * 100) : 0,
      count: dayApps.length
    };
  }, [selectedDate, appointments, bizConfig]);

  const filteredClients = useMemo(() => {
    return clients.filter(c => 
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      c.phone.includes(searchQuery)
    );
  }, [clients, searchQuery]);

  const isLunchTime = (hour: number) => {
    const lunchStart = parseInt(bizConfig.lunchStart?.split(':')[0] || '12');
    const lunchEnd = parseInt(bizConfig.lunchEnd?.split(':')[0] || '13');
    return hour >= lunchStart && hour < lunchEnd;
  };

  const openQuickSchedule = (date?: string, time?: string) => {
    setFormData({
        ...formData,
        date: date || selectedDate.toISOString().split('T')[0],
        time: time || '09:00',
        clientId: '',
        clientName: '',
        phone: '',
        serviceId: ''
    });
    setAppointmentStep('type');
    setIsNewAppointmentOpen(true);
  };

  const handleConfirmAppointment = () => {
    // 1. Bloqueio de horário ocupado
    const hasConflict = appointments.some(a => 
      a.appointment_date === formData.date && 
      a.appointment_time === formData.time &&
      a.status !== AppointmentStatus.Cancelled
    );

    if (hasConflict) {
      setNotification({ message: `Horário ${formData.time} já está ocupado!`, type: 'error' });
      setTimeout(() => setNotification(null), 4000);
      return;
    }

    if (clientType === 'new' && (!formData.clientName || !formData.phone)) {
       alert("Preencha nome e WhatsApp.");
       return;
    }

    let targetClient: Client | null = null;
    let updatedClientsList = [...clients];

    // 2. Lógica de CRUZAMENTO DE DADOS (Sincronização com a Base)
    if (clientType === 'new') {
        const existing = clients.find(c => c.phone === formData.phone);
        if (existing) {
            targetClient = existing;
            setNotification({ message: "Cliente já existia na base. Vinculando agendamento...", type: 'success' });
        } else {
            const newClient: Client = calculateClientRisk({
                id: `c-${Date.now()}`,
                name: formData.clientName,
                phone: formData.phone,
                total_visits: 1,
                average_service_value: 0,
                average_frequency_days: 30,
                is_inactive: false,
                days_since_last_visit: 0,
                risk_level: RiskLevel.None,
                risk_percentage: 0,
                trend_direction: TrendDirection.Stable,
                last_visit: formData.date,
                avatar_url: `https://ui-avatars.com/api/?name=${encodeURIComponent(formData.clientName)}&background=random`
            });
            updatedClientsList = [newClient, ...clients];
            targetClient = newClient;
        }
    } else {
        targetClient = clients.find(c => c.id === formData.clientId) || null;
    }

    if (!targetClient) return;

    // Atualiza a última visita do cliente na base para refletir o agendamento atual
    const clientIndex = updatedClientsList.findIndex(c => c.id === targetClient?.id);
    if (clientIndex !== -1) {
        updatedClientsList[clientIndex] = calculateClientRisk({
            ...updatedClientsList[clientIndex],
            last_visit: formData.date,
            total_visits: updatedClientsList[clientIndex].total_visits + 1
        });
    }

    // 3. Persistência Final (Cruza Agenda e Base de Clientes)
    setClients(updatedClientsList);
    localStorage.setItem('trendflow_clients', JSON.stringify(updatedClientsList));

    const selectedService = MOCK_SERVICES.find(s => s.id === formData.serviceId);
    const newAppointment: Appointment = {
        id: `a-${Date.now()}`,
        client_id: targetClient.id,
        client_name: targetClient.name,
        service_id: formData.serviceId,
        service_name: selectedService?.name || 'Serviço',
        appointment_date: formData.date,
        appointment_time: formData.time,
        duration_minutes: selectedService?.duration_minutes || 40,
        price: selectedService?.price || 0,
        status: AppointmentStatus.Scheduled,
        barber_id: 'b1'
    };

    const updatedApps = [...appointments, newAppointment];
    setAppointments(updatedApps);
    localStorage.setItem('trendflow_appointments', JSON.stringify(updatedApps));
    
    setNotification({ message: `Sucesso: ${targetClient.name} agendado e salvo na base!`, type: 'success' });
    setTimeout(() => setNotification(null), 4000);
    setIsNewAppointmentOpen(false);
  };

  const getAppointmentsForDay = (dateStr: string) => appointments.filter(a => a.appointment_date === dateStr);
  const getAppointmentForSlot = (dateStr: string, hour: number) => appointments.find(a => a.appointment_date === dateStr && parseInt(a.appointment_time.split(':')[0]) === hour);

  const monthDays = useMemo(() => {
    const year = selectedDate.getFullYear();
    const month = selectedDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const calendar = [];
    for (let i = 0; i < firstDay; i++) calendar.push(null);
    for (let d = 1; d <= daysInMonth; d++) calendar.push(d);
    return calendar;
  }, [selectedDate]);

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col space-y-4 animate-in fade-in duration-500 relative">
      {notification && (
        <div className={`absolute top-4 right-4 z-[60] px-6 py-4 rounded-2xl shadow-2xl flex items-center space-x-3 animate-in slide-in-from-right duration-300 border ${
          notification.type === 'success' ? 'bg-emerald-600 text-white border-emerald-500' : 'bg-red-600 text-white border-red-500'
        }`}>
           {notification.type === 'success' ? <Bell size={20} className="animate-bounce" /> : <AlertTriangle size={20} className="animate-pulse" />}
           <span className="font-bold">{notification.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex flex-col md:flex-row justify-between items-center gap-4 shadow-sm transition-colors">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-black text-zinc-900 dark:text-white capitalize min-w-[200px]">
            {selectedDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
          </h2>
          <div className="flex items-center bg-zinc-100 dark:bg-zinc-800 rounded-xl p-1">
            <button onClick={() => {
                const prev = new Date(selectedDate);
                if (view === 'month') prev.setMonth(prev.getMonth() - 1);
                else if (view === 'week') prev.setDate(prev.getDate() - 7);
                else prev.setDate(prev.getDate() - 1);
                setSelectedDate(prev);
            }} className="p-2 hover:bg-white dark:hover:bg-zinc-700 rounded-lg transition-all text-zinc-600 dark:text-zinc-300"><ChevronLeft size={20} /></button>
            <button onClick={() => setSelectedDate(new Date())} className="px-4 text-xs font-black text-zinc-700 dark:text-zinc-200 uppercase tracking-tighter">Hoje</button>
            <button onClick={() => {
                const next = new Date(selectedDate);
                if (view === 'month') next.setMonth(next.getMonth() + 1);
                else if (view === 'week') next.setDate(next.getDate() + 7);
                else next.setDate(next.getDate() + 1);
                setSelectedDate(next);
            }} className="p-2 hover:bg-white dark:hover:bg-zinc-700 rounded-lg transition-all text-zinc-600 dark:text-zinc-300"><ChevronRight size={20} /></button>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl mr-4">
            {(['day', 'week', 'month'] as ViewType[]).map((v) => (
              <button key={v} onClick={() => setView(v)} className={`px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${view === v ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-sm' : 'text-zinc-500 dark:text-zinc-400'}`}>
                {v === 'day' ? 'Dia' : v === 'week' ? 'Semana' : 'Mês'}
              </button>
            ))}
          </div>
          <button onClick={() => openQuickSchedule()} className="bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl font-bold flex items-center shadow-lg shadow-primary-500/20 transition-all hover:-translate-y-0.5">
            <Plus size={18} className="mr-2" />
            Novo Agendamento
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm flex flex-col transition-colors">
        {view === 'month' && (
          <div className="flex-1 grid grid-cols-7 h-full divide-x divide-y divide-zinc-100 dark:divide-zinc-800 overflow-auto">
            {DAYS.map(d => (
              <div key={d} className="p-3 text-center text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest bg-zinc-50 dark:bg-zinc-900/50">{d}</div>
            ))}
            {monthDays.map((day, i) => {
              const dateStr = day ? `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}` : '';
              const dayApps = day ? getAppointmentsForDay(dateStr) : [];
              return (
                <div key={i} className={`p-2 min-h-[120px] relative group transition-colors ${!day ? 'bg-zinc-50/30 dark:bg-zinc-950/20' : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/50'}`}>
                  {day && (
                    <>
                      <div className="flex justify-between items-start">
                         <span className={`text-sm font-bold ${day === new Date().getDate() && selectedDate.getMonth() === new Date().getMonth() ? 'bg-primary-500 text-white w-7 h-7 flex items-center justify-center rounded-full' : 'text-zinc-700 dark:text-zinc-400'}`}>{day}</span>
                         <button onClick={() => openQuickSchedule(dateStr)} className="opacity-0 group-hover:opacity-100 p-1 bg-zinc-100 dark:bg-zinc-700 rounded-md text-primary-500 transition-all"><Plus size={14} /></button>
                      </div>
                      <div className="mt-2 space-y-1 overflow-hidden">
                        {dayApps.map(a => (
                            <div key={a.id} className="bg-primary-50 dark:bg-primary-900/20 border-l-2 border-primary-500 p-1 rounded text-[9px] text-primary-700 dark:text-primary-400 truncate font-black">{a.appointment_time} - {a.client_name}</div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {view === 'week' && (
           <div className="flex-1 overflow-auto">
             <div className="min-w-[800px]">
                <div className="grid grid-cols-8 border-b border-zinc-100 dark:border-zinc-800 sticky top-0 bg-white dark:bg-zinc-900 z-10 shadow-sm">
                   <div className="p-4"></div>
                   {DAYS.map((d, i) => {
                      const dayDate = new Date(selectedDate);
                      dayDate.setDate(selectedDate.getDate() - selectedDate.getDay() + i);
                      const isToday = dayDate.toDateString() === new Date().toDateString();
                      return (
                        <div key={d} className={`p-4 text-center border-l border-zinc-100 dark:border-zinc-800 ${isToday ? 'bg-primary-50/20 dark:bg-primary-900/10' : ''}`}>
                           <span className="block text-xs font-bold text-zinc-400 dark:text-zinc-500 uppercase">{d}</span>
                           <span className={`text-xl font-black ${isToday ? 'text-primary-500' : 'text-zinc-900 dark:text-white'}`}>{dayDate.getDate()}</span>
                        </div>
                      );
                   })}
                </div>
                {HOURS.map(h => (
                   <div key={h} className="grid grid-cols-8 min-h-[80px] border-b border-zinc-50 dark:border-zinc-800/50">
                      <div className="p-4 text-xs font-bold text-zinc-400 dark:text-zinc-500 text-right">{h}:00</div>
                      {DAYS.map((_, i) => {
                         const isBlocked = isLunchTime(h);
                         const dayDate = new Date(selectedDate);
                         dayDate.setDate(selectedDate.getDate() - selectedDate.getDay() + i);
                         const dateStr = dayDate.toISOString().split('T')[0];
                         const app = getAppointmentForSlot(dateStr, h);
                         return (
                           <div key={i} className={`border-l border-zinc-100 dark:border-zinc-800 relative group p-1 ${isBlocked ? 'bg-zinc-100/30 dark:bg-zinc-800/20' : ''}`}>
                              {app ? (
                                <div className="bg-primary-500 text-white p-2 rounded-lg h-full text-[9px] font-black shadow-lg shadow-primary-500/20 flex flex-col justify-center">
                                   <div className="truncate">{app.client_name}</div>
                                   <div className="opacity-80 truncate uppercase tracking-tighter">{app.service_name}</div>
                                </div>
                              ) : isBlocked ? (
                                <div className="h-full w-full flex items-center justify-center opacity-30"><Clock size={16} className="text-zinc-400" /></div>
                              ) : (
                                <button onClick={() => openQuickSchedule(dateStr, `${String(h).padStart(2, '0')}:00`)} className="absolute inset-0 w-full h-full opacity-0 group-hover:opacity-100 bg-white/60 dark:bg-zinc-800/60 flex items-center justify-center transition-all"><Plus size={24} className="text-primary-500 scale-0 group-hover:scale-100 transition-transform" /></button>
                              )}
                           </div>
                         );
                      })}
                   </div>
                ))}
             </div>
           </div>
        )}

        {view === 'day' && (
           <div className="flex-1 flex overflow-hidden">
              <div className="w-1/3 border-r border-zinc-100 dark:border-zinc-800 p-6 space-y-6 bg-zinc-50/30 dark:bg-zinc-900/30">
                 <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-primary-500 rounded-2xl flex flex-col items-center justify-center text-white shadow-lg shadow-primary-500/20">
                       <span className="text-[10px] font-black uppercase">{selectedDate.toLocaleDateString('pt-BR', { weekday: 'short' })}</span>
                       <span className="text-2xl font-black">{selectedDate.getDate()}</span>
                    </div>
                    <div>
                       <h3 className="font-black text-xl text-zinc-900 dark:text-white capitalize">{selectedDate.toLocaleDateString('pt-BR', { month: 'long' })}</h3>
                       <p className="text-xs text-zinc-500 font-bold uppercase tracking-widest mt-1">{occupancyStats.count} Agendamentos</p>
                    </div>
                 </div>
                 <div className="bg-white dark:bg-zinc-900 p-5 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-sm relative overflow-hidden">
                    <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3">Ocupação Real</p>
                    <div className="flex items-center justify-between mb-2">
                       <span className="text-3xl font-black text-zinc-900 dark:text-white">{occupancyStats.rate}%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                       <div className="h-full bg-primary-500 transition-all duration-700" style={{width: `${occupancyStats.rate}%`}}></div>
                    </div>
                 </div>
              </div>
              <div className="flex-1 overflow-y-auto p-6 scroll-smooth">
                 {HOURS.map(h => {
                    const isBlocked = isLunchTime(h);
                    const app = getAppointmentForSlot(selectedDate.toISOString().split('T')[0], h);
                    return (
                        <div key={h} className="flex items-start mb-6 group">
                            <div className="w-20 pt-1 text-sm font-black text-zinc-400 dark:text-zinc-500">{String(h).padStart(2, '0')}:00</div>
                            <div className={`flex-1 min-h-[80px] border-l-2 pl-6 relative ${isBlocked ? 'border-zinc-200 dark:border-zinc-800' : 'border-zinc-100 dark:border-zinc-800'}`}>
                                {isBlocked ? (
                                    <div className="h-16 bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800 rounded-2xl flex items-center px-4 space-x-3 opacity-50"><AlertCircle size={18} className="text-zinc-400" /><span className="text-sm font-bold text-zinc-400 uppercase tracking-widest italic">Reservado (Almoço)</span></div>
                                ) : app ? (
                                    <div className="bg-white dark:bg-zinc-900 border-2 border-primary-500 rounded-2xl p-4 shadow-xl shadow-zinc-900/5 flex items-center justify-between hover:scale-[1.01] transition-all cursor-pointer">
                                        <div className="flex items-center space-x-4">
                                            <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center font-bold text-primary-600 uppercase">{app.client_name.substring(0,2)}</div>
                                            <div><p className="font-black text-zinc-900 dark:text-white">{app.client_name.toUpperCase()}</p><p className="text-xs text-zinc-500 font-bold uppercase tracking-tighter">{app.service_name} • R$ {app.price.toFixed(2)}</p></div>
                                        </div>
                                        <div className="flex items-center space-x-2"><span className="px-3 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 text-[10px] font-black uppercase rounded-full">Confirmado</span></div>
                                    </div>
                                ) : (
                                    <button onClick={() => openQuickSchedule(selectedDate.toISOString().split('T')[0], `${String(h).padStart(2, '0')}:00`)} className="w-full h-16 border-2 border-dashed border-zinc-100 dark:border-zinc-800 rounded-2xl flex items-center justify-center text-zinc-300 dark:text-zinc-700 hover:border-primary-500 hover:text-primary-500 hover:bg-primary-50/10 transition-all opacity-0 group-hover:opacity-100"><Plus size={24} /></button>
                                )}
                            </div>
                        </div>
                    );
                 })}
              </div>
           </div>
        )}
      </div>

      {isNewAppointmentOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-zinc-950 rounded-[32px] shadow-2xl w-full max-w-2xl overflow-hidden border border-zinc-200 dark:border-zinc-800">
            <div className="px-8 py-6 border-b border-zinc-100 dark:border-zinc-800 flex justify-between items-center bg-zinc-50/50 dark:bg-zinc-900/50">
              <h3 className="font-black text-2xl text-zinc-900 dark:text-white flex items-center tracking-tight"><CalendarIcon size={24} className="mr-3 text-primary-500" />Agendar Horário</h3>
              <button onClick={() => setIsNewAppointmentOpen(false)} className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"><X size={28} /></button>
            </div>
            <div className="p-8">
              {appointmentStep === 'type' ? (
                <div className="space-y-8">
                   <p className="text-zinc-500 dark:text-zinc-400 text-center text-lg">Para quem é este agendamento?</p>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <button onClick={() => { setClientType('base'); setAppointmentStep('details'); }} className="group p-8 bg-zinc-50 dark:bg-zinc-900 border-2 border-transparent hover:border-primary-500 rounded-3xl transition-all flex flex-col items-center text-center shadow-sm hover:shadow-xl hover:-translate-y-1"><div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><Users size={32} className="text-primary-600 dark:text-primary-400" /></div><h4 className="font-black text-xl text-zinc-900 dark:text-white mb-2">Cliente da Base</h4><p className="text-sm text-zinc-500">Já frequenta a barbearia.</p></button>
                      <button onClick={() => { setClientType('new'); setAppointmentStep('details'); }} className="group p-8 bg-zinc-50 dark:bg-zinc-900 border-2 border-transparent hover:border-emerald-500 rounded-3xl transition-all flex flex-col items-center text-center shadow-sm hover:shadow-xl hover:-translate-y-1"><div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><UserPlus size={32} className="text-emerald-600 dark:text-emerald-400" /></div><h4 className="font-black text-xl text-zinc-900 dark:text-white mb-2">Novo Cliente</h4><p className="text-sm text-zinc-500">Salvar automaticamente na base.</p></button>
                   </div>
                </div>
              ) : (
                <div className="space-y-6 animate-in slide-in-from-right duration-300">
                   <div className="flex items-center justify-between"><button onClick={() => setAppointmentStep('type')} className="text-sm font-bold text-primary-500 hover:underline">← Voltar</button><span className="text-xs font-black uppercase text-zinc-400 tracking-widest">{clientType === 'base' ? 'Base de Clientes' : 'Cadastro Novo'}</span></div>
                   {clientType === 'base' ? (
                      <div>
                        <label className="block text-xs font-black text-zinc-400 uppercase mb-2">Buscar</label>
                        <div className="relative"><Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" /><input autoFocus type="text" placeholder="Nome ou WhatsApp..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-12 pr-4 py-4 bg-zinc-100 dark:bg-zinc-900 border-none rounded-2xl text-zinc-900 dark:text-white outline-none" /></div>
                        <div className="mt-4 max-h-40 overflow-y-auto space-y-2 pr-2">{filteredClients.map(c => (<button key={c.id} onClick={() => setFormData({...formData, clientId: c.id, clientName: c.name, phone: c.phone})} className={`w-full text-left p-3 rounded-xl flex items-center justify-between transition-colors ${formData.clientId === c.id ? 'bg-primary-500 text-white' : 'bg-zinc-50 dark:bg-zinc-900 hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}><div className="flex items-center space-x-3"><div className="w-8 h-8 rounded-full bg-zinc-200 dark:bg-zinc-700 flex items-center justify-center text-xs font-bold text-zinc-600">{c.name.substring(0,2)}</div><span className="font-bold text-sm">{c.name}</span></div>{formData.clientId === c.id && <CheckCircle2 size={16} />}</button>))}</div>
                      </div>
                   ) : (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="col-span-2"><label className="block text-xs font-black text-zinc-400 uppercase mb-2">Nome</label><input type="text" autoFocus value={formData.clientName} onChange={e => setFormData({...formData, clientName: e.target.value})} className="w-full px-4 py-3 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none" /></div>
                        <div><label className="block text-xs font-black text-zinc-400 uppercase mb-2">WhatsApp</label><input type="text" placeholder="(11) 99999-9999" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-3 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none" /></div>
                      </div>
                   )}
                   <div className="grid grid-cols-2 gap-4">
                      <div><label className="block text-xs font-black text-zinc-400 uppercase mb-2">Data</label><input type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="w-full px-4 py-3 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-zinc-900 dark:text-white" /></div>
                      <div><label className="block text-xs font-black text-zinc-400 uppercase mb-2">Hora</label><select value={formData.time} onChange={e => setFormData({...formData, time: e.target.value})} className="w-full px-4 py-3 bg-zinc-100 dark:bg-zinc-900 rounded-xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none appearance-none">{HOURS.map(h => (<option key={h} value={`${String(h).padStart(2, '0')}:00`}>{String(h).padStart(2, '0')}:00</option>))}</select></div>
                   </div>
                   <div>
                      <label className="block text-xs font-black text-zinc-400 uppercase mb-2">Serviço</label>
                      <div className="grid grid-cols-2 gap-2">{MOCK_SERVICES.map(s => (<button key={s.id} onClick={() => setFormData({...formData, serviceId: s.id})} className={`p-3 rounded-xl border-2 text-left transition-all ${formData.serviceId === s.id ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : 'border-zinc-100 dark:border-zinc-800'}`}><p className="text-xs font-black text-zinc-900 dark:text-white">{s.name}</p><p className="text-[10px] text-zinc-500">R$ {s.price.toFixed(2)}</p></button>))}</div>
                   </div>
                   <button onClick={handleConfirmAppointment} className="w-full py-4 bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 font-black text-lg rounded-2xl shadow-xl hover:opacity-90 transition-all flex items-center justify-center space-x-2"><span>Agendar e Salvar na Base</span><CheckCircle2 size={20} /></button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

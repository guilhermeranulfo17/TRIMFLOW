import React, { useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { TrendingUp, DollarSign, Scissors, Calendar, ArrowLeft, Download, Filter, Target } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const REVENUE_BY_SERVICE = [
  { name: 'Corte Degradê', value: 5400, color: '#22c55e' },
  { name: 'Barba Modelada', value: 3100, color: '#3b82f6' },
  { name: 'Combo Completo', value: 4080, color: '#f59e0b' },
];

const REVENUE_BY_DAY = [
  { day: 'Seg', value: 1200 }, { day: 'Ter', value: 1500 }, { day: 'Qua', value: 1100 },
  { day: 'Qui', value: 2400 }, { day: 'Sex', value: 3800 }, { day: 'Sab', value: 4200 },
];

export const Reports = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'finance' | 'services' | 'clients'>('finance');

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => navigate('/')}
            className="p-3 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-2xl transition-colors text-zinc-500"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-black text-zinc-900 dark:text-white tracking-tight">Resultados Detalhados</h1>
            <p className="text-zinc-500 dark:text-zinc-400 font-medium">Análise operacional e financeira completa.</p>
          </div>
        </div>
        <div className="flex space-x-2">
           <button className="flex items-center space-x-2 bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 px-4 py-2.5 rounded-xl text-sm font-bold border border-zinc-200 dark:border-zinc-700">
             <Filter size={18} />
             <span>Filtrar Período</span>
           </button>
           <button className="flex items-center space-x-2 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 px-5 py-2.5 rounded-xl text-sm font-black shadow-lg">
             <Download size={18} />
             <span>Relatório PDF</span>
           </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 bg-zinc-100 dark:bg-zinc-900 p-1.5 rounded-2xl w-fit border border-zinc-200 dark:border-zinc-800 shadow-inner">
         {(['finance', 'services', 'clients'] as const).map((tab) => (
           <button 
             key={tab}
             onClick={() => setActiveTab(tab)}
             className={`px-6 py-2.5 rounded-xl text-sm font-black transition-all ${
               activeTab === tab 
                 ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-lg' 
                 : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-700'
             }`}
           >
             {tab === 'finance' ? 'Financeiro' : tab === 'services' ? 'Serviços' : 'Clientes'}
           </button>
         ))}
      </div>

      {activeTab === 'finance' && (
        <div className="space-y-8">
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-sm relative overflow-hidden">
                 <div className="absolute -right-4 -bottom-4 opacity-5 text-zinc-900 dark:text-white"><DollarSign size={120} /></div>
                 <p className="text-xs font-black text-zinc-400 uppercase tracking-widest mb-2">Faturamento Total</p>
                 <h3 className="text-3xl font-black text-zinc-900 dark:text-white">R$ 12.580,00</h3>
                 <p className="text-xs text-emerald-500 mt-4 flex items-center font-bold">
                    <TrendingUp size={14} className="mr-1" /> +15.9% vs mês anterior
                 </p>
              </div>
              <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
                 <p className="text-xs font-black text-zinc-400 uppercase tracking-widest mb-2">Ticket Médio</p>
                 <h3 className="text-3xl font-black text-zinc-900 dark:text-white">R$ 52,40</h3>
                 <p className="text-xs text-blue-500 mt-4 flex items-center font-bold">
                    Crescimento orgânico estável
                 </p>
              </div>
              <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
                 <p className="text-xs font-black text-zinc-400 uppercase tracking-widest mb-2">Lucro Projetado</p>
                 <h3 className="text-3xl font-black text-emerald-500">R$ 8.940,00</h3>
                 <p className="text-xs text-zinc-500 mt-4">Após custos operacionais fixos</p>
              </div>
           </div>

           <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
              <h2 className="text-lg font-black text-zinc-900 dark:text-white mb-8">Curva de Faturamento Diário</h2>
              <div className="h-80 w-full">
                 <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={REVENUE_BY_DAY}>
                       <defs>
                          <linearGradient id="colorReport" x1="0" y1="0" x2="0" y2="1">
                             <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                             <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                          </linearGradient>
                       </defs>
                       <CartesianGrid strokeDasharray="3 3" vertical={false} strokeOpacity={0.1} />
                       <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#a1a1aa', fontSize: 12}} />
                       <YAxis axisLine={false} tickLine={false} tick={{fill: '#a1a1aa', fontSize: 12}} />
                       <Tooltip contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                       <Area type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={4} fill="url(#colorReport)" />
                    </AreaChart>
                 </ResponsiveContainer>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'services' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
           <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
              <h2 className="text-lg font-black text-zinc-900 dark:text-white mb-8">Participação por Serviço</h2>
              <div className="h-80 w-full">
                 <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={REVENUE_BY_SERVICE} layout="vertical">
                       <XAxis type="number" hide />
                       <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fill: '#a1a1aa', fontSize: 12}} width={120} />
                       <Tooltip cursor={{fill: 'transparent'}} />
                       <Bar dataKey="value" radius={[0, 8, 8, 0]} barSize={40}>
                          {REVENUE_BY_SERVICE.map((entry, index) => <Cell key={index} fill={entry.color} />)}
                       </Bar>
                    </BarChart>
                 </ResponsiveContainer>
              </div>
           </div>
           
           <div className="bg-white dark:bg-zinc-900 p-8 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
              <h2 className="text-lg font-black text-zinc-900 dark:text-white mb-6">Eficiência de Cadeira</h2>
              <div className="space-y-6">
                 {[
                   { label: 'Corte Degradê', time: '40min', eff: 85 },
                   { label: 'Barba Modelada', time: '30min', eff: 72 },
                   { label: 'Combo Completo', time: '60min', eff: 94 },
                 ].map(item => (
                   <div key={item.label}>
                      <div className="flex justify-between items-center mb-2">
                         <span className="text-sm font-bold text-zinc-700 dark:text-zinc-200">{item.label}</span>
                         <span className="text-xs font-black text-primary-500">{item.eff}% Rentável</span>
                      </div>
                      <div className="w-full h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                         <div className="h-full bg-primary-500" style={{width: `${item.eff}%`}}></div>
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
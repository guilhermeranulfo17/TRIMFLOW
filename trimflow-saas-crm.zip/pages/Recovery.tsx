
import React, { useState, useMemo, useEffect } from 'react';
import { 
  BrainCircuit, 
  Send, 
  DollarSign, 
  TrendingUp, 
  MessageSquare, 
  Zap, 
  ShieldAlert,
  Target,
  Sparkles,
  Coffee,
  TicketPercent
} from 'lucide-react';
import { MOCK_CLIENTS } from '../services/mockData';
import { RiskLevel, Client, BusinessConfig } from '../types';
import { useClientRecovery } from '../hooks/useClientRecovery';

const translateRisk = (level: RiskLevel) => {
  switch (level) {
    case RiskLevel.Critical: return 'Crítico';
    case RiskLevel.Moderate: return 'Moderado';
    case RiskLevel.Light: return 'Leve';
    case RiskLevel.None: return 'Seguro';
    default: return level;
  }
};

const getRiskColor = (level: RiskLevel) => {
  switch (level) {
    case RiskLevel.Critical: return 'text-red-500 bg-red-500/10';
    case RiskLevel.Moderate: return 'text-orange-500 bg-orange-500/10';
    case RiskLevel.Light: return 'text-yellow-500 bg-yellow-500/10';
    case RiskLevel.None: return 'text-emerald-500 bg-emerald-500/10';
  }
};

export const Recovery = () => {
  const [filter, setFilter] = useState<RiskLevel | 'all'>('all');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [strategy, setStrategy] = useState<'friendly' | 'offer' | 'vip'>('friendly');
  const [shopName, setShopName] = useState('Trim Flow');
  const { aiMessage, setAiMessage, isGenerating, generateRecoveryMessage } = useClientRecovery();

  useEffect(() => {
    const configStr = localStorage.getItem('trendflow_config');
    if (configStr) {
      const config: BusinessConfig = JSON.parse(configStr);
      if (config.shopName) setShopName(config.shopName);
    }
  }, []);

  const clients: Client[] = useMemo(() => {
    const saved = localStorage.getItem('trendflow_clients');
    return saved ? JSON.parse(saved) : MOCK_CLIENTS;
  }, []);

  const filteredClients = useMemo(() => {
    let list = clients.filter(c => filter === 'all' ? true : c.risk_level === filter);
    return list.sort((a, b) => (b.average_service_value * b.days_since_last_visit) - (a.average_service_value * a.days_since_last_visit));
  }, [clients, filter]);

  const priorityTargets = useMemo(() => {
    return clients
      .filter(c => c.risk_level === RiskLevel.Critical || c.risk_level === RiskLevel.Moderate)
      .sort((a, b) => b.average_service_value - a.average_service_value)
      .slice(0, 3);
  }, [clients]);

  const moneyOnTable = useMemo(() => clients
    .filter(c => c.risk_level !== RiskLevel.None)
    .reduce((acc, curr) => acc + (curr.average_service_value || 50), 0), [clients]);

  const handleSendWhatsApp = () => {
    if (!selectedClient || !aiMessage) return;
    const phone = selectedClient.phone.replace(/\D/g, '');
    const text = encodeURIComponent(aiMessage);
    window.open(`https://wa.me/55${phone}?text=${text}`, '_blank');
  };

  const handleGenerateAI = () => {
    if (!selectedClient) return;
    generateRecoveryMessage(selectedClient, shopName, strategy);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Top Banner: Financial Potential */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gradient-to-br from-zinc-900 to-zinc-800 dark:from-white dark:to-zinc-200 rounded-[40px] p-8 text-white dark:text-zinc-900 shadow-2xl relative overflow-hidden flex flex-col justify-center">
          <div className="relative z-10">
            <p className="text-zinc-400 dark:text-zinc-500 font-black text-[10px] uppercase tracking-[0.2em] mb-2">Potencial de Recuperação Estimado</p>
            <div className="flex items-baseline space-x-3">
              <h2 className="text-6xl font-black tracking-tighter">R$ {moneyOnTable.toLocaleString('pt-BR')}</h2>
              <span className="text-emerald-400 dark:text-emerald-600 font-bold text-sm flex items-center bg-emerald-500/10 px-3 py-1 rounded-full"><TrendingUp size={16} className="mr-1" /> Oportunidade</span>
            </div>
            <p className="text-zinc-400 dark:text-zinc-500 mt-4 text-sm font-medium max-w-md">Este valor representa clientes que já passaram do tempo ideal de retorno e podem ser reativados com uma mensagem estratégica pela <b>{shopName}</b>.</p>
          </div>
          <DollarSign size={200} className="absolute -right-10 -bottom-10 opacity-5 dark:opacity-10 rotate-12" />
        </div>

        {/* Priority Targets Card */}
        <div className="bg-white dark:bg-zinc-900 rounded-[40px] p-8 border border-zinc-200 dark:border-zinc-800 shadow-sm">
          <h3 className="text-xs font-black text-zinc-400 uppercase tracking-widest mb-6 flex items-center">
            <Target size={16} className="mr-2 text-primary-500" /> Prioridade Máxima
          </h3>
          <div className="space-y-4">
            {priorityTargets.map(client => (
              <div key={client.id} onClick={() => setSelectedClient(client)} className="flex items-center justify-between p-3 hover:bg-zinc-50 dark:hover:bg-zinc-800 rounded-2xl cursor-pointer transition-all border border-transparent hover:border-zinc-100 dark:hover:border-zinc-700">
                <div className="flex flex-col">
                  <span className="font-black text-zinc-900 dark:text-white uppercase text-xs">{client.name}</span>
                  <span className="text-[10px] text-zinc-400 font-bold">Ticket: R$ {client.average_service_value}</span>
                </div>
                <div className="bg-red-500/10 text-red-500 p-2 rounded-xl"><Zap size={14} /></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-[600px]">
        {/* Client Selector List */}
        <div className="lg:col-span-5 flex flex-col bg-white dark:bg-zinc-900 rounded-[40px] border border-zinc-200 dark:border-zinc-800 overflow-hidden shadow-sm">
          <div className="p-6 border-b border-zinc-100 dark:border-zinc-800 flex items-center space-x-2 overflow-x-auto no-scrollbar">
            {(['all', RiskLevel.Critical, RiskLevel.Moderate, RiskLevel.Light] as const).map((lvl) => (
              <button 
                key={lvl} 
                onClick={() => setFilter(lvl)} 
                className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-full transition-all whitespace-nowrap ${filter === lvl ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 shadow-lg' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500 hover:bg-zinc-200'}`}
              >
                {lvl === 'all' ? 'Todos' : translateRisk(lvl as RiskLevel)}
              </button>
            ))}
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {filteredClients.map(client => (
              <div 
                key={client.id} 
                onClick={() => { setSelectedClient(client); setAiMessage(''); }} 
                className={`p-5 rounded-3xl cursor-pointer border-2 transition-all flex items-center justify-between group ${selectedClient?.id === client.id ? 'border-primary-500 bg-primary-50/10 dark:bg-primary-500/5' : 'border-transparent bg-zinc-50/50 dark:bg-zinc-800/30 hover:bg-zinc-100 dark:hover:bg-zinc-800/60'}`}
              >
                <div className="flex flex-col">
                  <h4 className={`font-black uppercase text-sm tracking-tight transition-colors ${selectedClient?.id === client.id ? 'text-primary-600' : 'text-zinc-900 dark:text-white'}`}>{client.name}</h4>
                  <div className="flex items-center mt-1 space-x-2">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{client.phone}</span>
                    <span className="w-1 h-1 bg-zinc-300 rounded-full"></span>
                    <span className="text-[10px] font-black text-primary-500 uppercase tracking-tighter">R$ {client.average_service_value}</span>
                  </div>
                </div>
                <div className="text-right flex flex-col items-end">
                  <div className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase ${getRiskColor(client.risk_level)}`}>
                    {translateRisk(client.risk_level)}
                  </div>
                  <span className="text-[10px] text-zinc-400 font-bold mt-2 uppercase">{client.days_since_last_visit} dias</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Action Panel */}
        <div className="lg:col-span-7 flex flex-col bg-white dark:bg-zinc-900 rounded-[40px] border border-zinc-200 dark:border-zinc-800 overflow-hidden shadow-sm">
          {!selectedClient ? (
            <div className="h-full flex flex-col items-center justify-center p-12 text-center opacity-30">
              <div className="w-24 h-24 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mb-6">
                <BrainCircuit size={48} className="text-zinc-400" />
              </div>
              <p className="text-zinc-500 font-black text-xs uppercase tracking-[0.2em] leading-relaxed">
                Selecione um cliente para<br/>ativar o motor de inteligência
              </p>
            </div>
          ) : (
            <div className="flex-1 flex flex-col animate-in slide-in-from-right-4 duration-500">
              {/* Profile Context */}
              <div className="p-8 bg-zinc-50/50 dark:bg-zinc-800/20 border-b border-zinc-100 dark:border-zinc-800">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="font-black text-2xl text-zinc-900 dark:text-white tracking-tighter uppercase">{selectedClient.name}</h3>
                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Analise de Comportamento • {selectedClient.total_visits} Visitas Totais</p>
                  </div>
                  <div className={`p-4 rounded-3xl ${getRiskColor(selectedClient.risk_level)} flex flex-col items-center justify-center min-w-[100px]`}>
                    <span className="text-[10px] font-black uppercase">Status</span>
                    <span className="text-lg font-black tracking-tight">{translateRisk(selectedClient.risk_level)}</span>
                  </div>
                </div>

                {/* Strategy Selector */}
                <div className="grid grid-cols-3 gap-3">
                  <button 
                    onClick={() => setStrategy('friendly')} 
                    className={`flex flex-col items-center p-3 rounded-2xl border-2 transition-all ${strategy === 'friendly' ? 'border-primary-500 bg-primary-50/50 dark:bg-primary-500/10' : 'border-zinc-100 dark:border-zinc-800 bg-white dark:bg-zinc-900'}`}
                  >
                    <Coffee size={18} className={strategy === 'friendly' ? 'text-primary-500' : 'text-zinc-400'} />
                    <span className="text-[9px] font-black uppercase mt-2">Amigável</span>
                  </button>
                  <button 
                    onClick={() => setStrategy('offer')} 
                    className={`flex flex-col items-center p-3 rounded-2xl border-2 transition-all ${strategy === 'offer' ? 'border-orange-500 bg-orange-50/50 dark:bg-orange-500/10' : 'border-zinc-100 dark:border-zinc-800 bg-white dark:bg-zinc-900'}`}
                  >
                    <TicketPercent size={18} className={strategy === 'offer' ? 'text-orange-500' : 'text-zinc-400'} />
                    <span className="text-[9px] font-black uppercase mt-2">Oferta</span>
                  </button>
                  <button 
                    onClick={() => setStrategy('vip')} 
                    className={`flex flex-col items-center p-3 rounded-2xl border-2 transition-all ${strategy === 'vip' ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-500/10' : 'border-zinc-100 dark:border-zinc-800 bg-white dark:bg-zinc-900'}`}
                  >
                    <Sparkles size={18} className={strategy === 'vip' ? 'text-indigo-500' : 'text-zinc-400'} />
                    <span className="text-[9px] font-black uppercase mt-2">VIP</span>
                  </button>
                </div>
              </div>

              {/* Message Generator */}
              <div className="flex-1 p-8 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center text-zinc-400">
                    <MessageSquare size={16} className="mr-2" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Script Recomendado</span>
                  </div>
                  <button 
                    onClick={handleGenerateAI} 
                    disabled={isGenerating} 
                    className="bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 px-6 py-2 rounded-full text-[10px] font-black uppercase flex items-center shadow-xl hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
                  >
                    <BrainCircuit size={14} className="mr-2" />
                    {isGenerating ? 'Processando...' : 'Re-Gerar com IA'}
                  </button>
                </div>
                
                <textarea 
                  className="flex-1 bg-zinc-50 dark:bg-zinc-800/50 border-none rounded-[32px] p-6 text-zinc-700 dark:text-zinc-200 text-sm font-medium outline-none resize-none leading-relaxed shadow-inner"
                  placeholder="Aguardando geração da estratégia..."
                  value={aiMessage}
                  onChange={(e) => setAiMessage(e.target.value)}
                />
              </div>

              {/* Final CTA */}
              <div className="p-8 border-t border-zinc-100 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/50">
                <button 
                  disabled={!aiMessage}
                  onClick={handleSendWhatsApp}
                  className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white font-black py-5 rounded-[24px] shadow-xl shadow-emerald-500/20 flex items-center justify-center transition-all hover:scale-[1.02] active:scale-95 disabled:opacity-30"
                >
                  <Send size={20} className="mr-3" />
                  Abrir no WhatsApp
                </button>
                <p className="text-center text-[9px] text-zinc-400 font-bold uppercase mt-4 tracking-widest">
                  A <b>{shopName}</b> utiliza IA para criar esta mensagem personalizada
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

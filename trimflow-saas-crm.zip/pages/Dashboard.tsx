
import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, AlertTriangle, DollarSign, Target, PlusCircle } from 'lucide-react';
import { Appointment, Client, BusinessConfig, UserAccount } from '../types';

export const Dashboard = () => {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState<'today' | 'week' | 'month'>('month');

  const [sessionUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('trimflow_session');
    return saved ? JSON.parse(saved) : null;
  });

  const bizConfig: BusinessConfig = useMemo(() => {
    if (!sessionUser) return {};
    return JSON.parse(localStorage.getItem(`trimflow_config_${sessionUser.id}`) || '{}');
  }, [sessionUser]);

  const appointments: Appointment[] = useMemo(() => {
    if (!sessionUser) return [];
    return JSON.parse(localStorage.getItem(`trimflow_appointments_${sessionUser.id}`) || '[]');
  }, [sessionUser]);

  const clients: Client[] = useMemo(() => {
    if (!sessionUser) return [];
    return JSON.parse(localStorage.getItem(`trimflow_clients_${sessionUser.id}`) || '[]');
  }, [sessionUser]);

  const stats = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const todayApps = appointments.filter(a => a.appointment_date === todayStr);
    const revenueToday = todayApps.reduce((acc, curr) => acc + curr.price, 0);
    const criticalRiskCount = clients.filter(c => c.risk_level === 'critical').length;

    return {
      revenue: revenueToday || 0,
      appointments: todayApps.length,
      clientsCount: clients.length,
      risk: criticalRiskCount
    };
  }, [appointments, clients]);

  const isEmpty = stats.revenue === 0 && stats.appointments === 0 && stats.clientsCount === 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold text-zinc-900 dark:text-white">Dashboard Executivo</h1>
           <p className="text-zinc-500 dark:text-zinc-400">Visão geral de {bizConfig.shopName}.</p>
        </div>
        <div className="flex space-x-1 bg-white dark:bg-zinc-900 p-1.5 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
           {(['today', 'week', 'month'] as const).map((range) => (
             <button 
               key={range}
               onClick={() => setTimeRange(range)}
               className={`px-4 py-1.5 text-sm font-medium rounded-lg transition-all ${
                 timeRange === range 
                   ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 shadow-sm' 
                   : 'text-zinc-500 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800'
               }`}
             >
               {range === 'today' ? 'Hoje' : range === 'week' ? 'Semana' : 'Mês'}
             </button>
           ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Faturamento Hoje" 
          value={`R$ ${stats.revenue.toLocaleString('pt-BR')}`}
          icon={DollarSign}
          colorClass="bg-emerald-500 text-emerald-600"
          onClick={() => navigate('/reports')}
        />
        <StatCard 
          title="Agendamentos Hoje" 
          value={stats.appointments}
          icon={Calendar} 
          colorClass="bg-blue-500 text-blue-600"
          onClick={() => navigate('/appointments')}
        />
        <StatCard 
          title="Clientes na Base" 
          value={stats.clientsCount}
          icon={Target} 
          colorClass="bg-indigo-500 text-indigo-600"
          onClick={() => navigate('/clients')}
        />
        <StatCard 
          title="Alertas de Risco" 
          value={stats.risk}
          icon={AlertTriangle} 
          colorClass="bg-red-500 text-red-600"
          onClick={() => navigate('/recovery')}
        />
      </div>

      {isEmpty && (
        <div className="bg-white dark:bg-zinc-900 border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-[40px] p-20 text-center space-y-6">
          <div className="w-20 h-20 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto text-zinc-400">
             <PlusCircle size={40} />
          </div>
          <div className="max-w-md mx-auto">
            <h2 className="text-xl font-bold text-zinc-900 dark:text-white">Seu sistema está pronto para rodar!</h2>
            <p className="text-zinc-500 dark:text-zinc-400 mt-2">Você ainda não tem agendamentos hoje. Que tal cadastrar seu primeiro cliente ou serviço?</p>
          </div>
          <div className="flex justify-center gap-4">
            <button 
              onClick={() => navigate('/appointments')}
              className="bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 px-8 py-3 rounded-2xl font-bold hover:scale-105 transition-all"
            >
              Novo Agendamento
            </button>
            <button 
              onClick={() => navigate('/services')}
              className="bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-white px-8 py-3 rounded-2xl font-bold hover:scale-105 transition-all"
            >
              Configurar Serviços
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const StatCard = ({ title, value, icon: Icon, colorClass, onClick }: any) => (
  <div 
    onClick={onClick}
    className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group cursor-pointer"
  >
    <div className="flex items-start justify-between mb-4">
      <div className={`p-3 rounded-xl ${colorClass} bg-opacity-10 dark:bg-opacity-20`}>
        <Icon className={`w-6 h-6 ${colorClass.replace('bg-', 'text-')}`} />
      </div>
    </div>
    <h3 className="text-3xl font-bold text-zinc-900 dark:text-white tracking-tight">{value}</h3>
    <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400 mt-1">{title}</p>
  </div>
);

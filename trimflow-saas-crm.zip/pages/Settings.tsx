
import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Clock, 
  Save, 
  Store, 
  User, 
  CheckCircle2
} from 'lucide-react';
import { BusinessConfig } from '../types';

const SettingsSection = ({ title, description, icon: Icon, children }: any) => (
  <div className="bg-white dark:bg-zinc-900 rounded-[32px] border border-zinc-200 dark:border-zinc-800 shadow-sm overflow-hidden transition-all hover:shadow-md">
    <div className="p-8 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between bg-zinc-50/30 dark:bg-zinc-900/50">
      <div className="flex items-center">
        <div className="p-3 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-2xl shadow-sm mr-5 text-primary-500">
          <Icon size={24} />
        </div>
        <div>
          <h3 className="text-xl font-black text-zinc-900 dark:text-white uppercase tracking-tight">{title}</h3>
          <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400 mt-0.5">{description}</p>
        </div>
      </div>
    </div>
    <div className="p-8">
      {children}
    </div>
  </div>
);

const InputField = ({ label, value, onChange, type = "text", placeholder, icon: Icon }: any) => (
  <div className="space-y-2">
    <label className="block text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">{label}</label>
    <div className="relative">
      {Icon && <Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />}
      <input 
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-800 rounded-2xl ${Icon ? 'pl-12' : 'px-6'} py-4 text-zinc-900 dark:text-white font-bold outline-none focus:ring-2 focus:ring-primary-500 transition-all placeholder:text-zinc-400 dark:placeholder:text-zinc-600`}
      />
    </div>
  </div>
);

export const Settings = () => {
  const [config, setConfig] = useState<BusinessConfig>(() => {
    // Check both local storage keys for cross-page compatibility
    const saved = localStorage.getItem('trimflow_config') || localStorage.getItem('trendflow_config');
    return saved ? JSON.parse(saved) : {
      shopName: 'Trim Flow',
      userName: 'Gestor',
      openingTime: '09:00',
      closingTime: '19:00',
      lunchStart: '12:00',
      lunchEnd: '13:00',
      onboardingCompleted: true
    };
  });

  const [showSuccess, setShowSuccess] = useState(false);

  const handleSave = () => {
    // Persist to both possible storage keys to ensure consistency
    localStorage.setItem('trendflow_config', JSON.stringify(config));
    localStorage.setItem('trimflow_config', JSON.stringify(config));
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-20 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-zinc-900 dark:text-white tracking-tighter uppercase">CONFIGURAÇÕES</h1>
          <p className="text-zinc-500 dark:text-zinc-400 font-bold uppercase text-[10px] tracking-[0.2em] mt-2">Personalize o coração da sua operação</p>
        </div>
        <button 
          onClick={handleSave}
          className="bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-900 px-10 py-4 rounded-3xl font-black text-xs uppercase tracking-widest flex items-center shadow-2xl transition-all hover:-translate-y-1 active:scale-95 group"
        >
          {showSuccess ? (
            <>
              <CheckCircle2 size={20} className="mr-3 text-emerald-500" />
              <span>Configurações Salvas</span>
            </>
          ) : (
            <>
              <Save size={20} className="mr-3 group-hover:rotate-12 transition-transform" />
              <span>Salvar Alterações</span>
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 gap-10">
        
        {/* Profile & Business */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <SettingsSection 
            title="Perfil do Gestor" 
            description="Informações do administrador do sistema" 
            icon={User}
          >
            <InputField 
              label="Nome Completo" 
              value={config.userName} 
              onChange={(val: string) => setConfig({...config, userName: val})} 
              icon={User}
              placeholder="Seu nome"
            />
          </SettingsSection>

          <SettingsSection 
            title="Sua Barbearia" 
            description="Identidade visual e branding" 
            icon={Store}
          >
            <InputField 
              label="Nome do Estabelecimento" 
              value={config.shopName} 
              onChange={(val: string) => setConfig({...config, shopName: val})} 
              icon={Store}
              placeholder="Ex: Trim Flow Premium"
            />
          </SettingsSection>
        </div>

        {/* Operating Hours */}
        <SettingsSection 
          title="Horários de Atendimento" 
          description="Controle de abertura, fechamento e intervalos" 
          icon={Clock}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-6">
              <h4 className="text-xs font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">Expediente Geral</h4>
              <div className="grid grid-cols-2 gap-4">
                <InputField 
                  label="Abertura" 
                  type="time" 
                  value={config.openingTime} 
                  onChange={(val: string) => setConfig({...config, openingTime: val})} 
                />
                <InputField 
                  label="Encerramento" 
                  type="time" 
                  value={config.closingTime} 
                  onChange={(val: string) => setConfig({...config, closingTime: val})} 
                />
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-xs font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 dark:border-zinc-800 pb-2">Intervalo (Bloqueio de Agenda)</h4>
              <div className="grid grid-cols-2 gap-4">
                <InputField 
                  label="Início" 
                  type="time" 
                  value={config.lunchStart} 
                  onChange={(val: string) => setConfig({...config, lunchStart: val})} 
                />
                <InputField 
                  label="Fim" 
                  type="time" 
                  value={config.lunchEnd} 
                  onChange={(val: string) => setConfig({...config, lunchEnd: val})} 
                />
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* System Info Footer */}
        <div className="pt-10 flex flex-col items-center justify-center space-y-4 opacity-40">
           <div className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-[0.3em] text-zinc-400">
             <span>Trim Flow</span>
             <span className="w-1 h-1 bg-zinc-400 rounded-full"></span>
             <span>v2.5 Premium</span>
             <span className="w-1 h-1 bg-zinc-400 rounded-full"></span>
             <span>SaaS Platform</span>
           </div>
           <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Segurança de dados e backups ativos</p>
        </div>
      </div>
    </div>
  );
};
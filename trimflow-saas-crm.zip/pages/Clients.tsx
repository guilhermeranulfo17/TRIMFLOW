
import React, { useState, useMemo } from 'react';
import { Search, X, Save, Clock, Calendar, User, Phone, ArrowUpDown, ChevronUp, ChevronDown } from 'lucide-react';
import { MOCK_CLIENTS } from '../services/mockData';
import { RiskLevel, Client } from '../types';
import { calculateClientRisk } from '../services/riskEngine';

type SortConfig = {
  key: keyof Client | 'absence';
  direction: 'asc' | 'desc';
};

const translateRisk = (level: RiskLevel) => {
  switch (level) {
    case RiskLevel.Critical: return 'Crítico';
    case RiskLevel.Moderate: return 'Moderado';
    case RiskLevel.Light: return 'Leve';
    case RiskLevel.None: return 'Seguro';
    default: return level;
  }
};

const getRiskColor = (level: RiskLevel) => {
  switch (level) {
    case RiskLevel.Critical: return 'text-red-600 bg-red-50 border-red-100 dark:bg-red-900/20 dark:text-red-400';
    case RiskLevel.Moderate: return 'text-orange-600 bg-orange-50 border-orange-100 dark:bg-orange-900/20 dark:text-orange-400';
    case RiskLevel.Light: return 'text-yellow-600 bg-yellow-50 border-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-400';
    case RiskLevel.None: return 'text-emerald-600 bg-emerald-50 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-400';
  }
};

const EditClientModal = ({ client, onClose, onSave }: { client: Client, onClose: () => void, onSave: (c: Client) => void }) => {
  const [formData, setFormData] = useState({ ...client });
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-zinc-900 rounded-[32px] shadow-2xl w-full max-w-lg overflow-hidden border border-zinc-200 dark:border-zinc-800">
        <div className="px-8 py-6 border-b border-zinc-100 dark:border-zinc-800 flex justify-between items-center bg-zinc-50/50 dark:bg-zinc-900/50">
          <h3 className="font-black text-xl text-zinc-900 dark:text-white uppercase tracking-tight">Editar Cliente</h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 transition-colors"><X size={24} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2">Nome Completo</label>
              <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-3 bg-zinc-100 dark:bg-zinc-800 border-none rounded-2xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2">WhatsApp</label>
              <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-3 bg-zinc-100 dark:bg-zinc-800 border-none rounded-2xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2">Última Visita</label>
              <input type="date" value={formData.last_visit} onChange={e => setFormData({...formData, last_visit: e.target.value})} className="w-full px-4 py-3 bg-zinc-100 dark:bg-zinc-800 border-none rounded-2xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none" />
            </div>
          </div>
          <div className="flex gap-3 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-4 text-sm font-black text-zinc-500 uppercase tracking-widest hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-2xl transition-colors">Cancelar</button>
            <button type="submit" className="flex-1 py-4 text-sm font-black text-white bg-zinc-900 dark:bg-white dark:text-zinc-900 rounded-2xl shadow-xl flex items-center justify-center uppercase tracking-widest"><Save size={18} className="mr-2" />Salvar</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const Clients = () => {
  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem('trendflow_clients');
    return saved ? JSON.parse(saved) : MOCK_CLIENTS;
  });
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'name', direction: 'asc' });

  const handleSaveClient = (updatedClientData: Client) => {
    const processedClient = calculateClientRisk(updatedClientData);
    const updated = clients.map(c => c.id === processedClient.id ? processedClient : c);
    setClients(updated);
    localStorage.setItem('trendflow_clients', JSON.stringify(updated));
    setEditingClient(null);
  };

  const handleSort = (key: SortConfig['key']) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const filteredClients = useMemo(() => {
    let result = clients.filter(client => 
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.phone.includes(searchQuery)
    );

    // Sorting logic
    result.sort((a, b) => {
      let valA: any;
      let valB: any;

      switch (sortConfig.key) {
        case 'name':
          valA = a.name.toLowerCase();
          valB = b.name.toLowerCase();
          break;
        case 'risk_level':
          const riskOrder = { [RiskLevel.Critical]: 3, [RiskLevel.Moderate]: 2, [RiskLevel.Light]: 1, [RiskLevel.None]: 0 };
          valA = riskOrder[a.risk_level];
          valB = riskOrder[b.risk_level];
          break;
        case 'last_visit':
          valA = a.last_visit ? new Date(a.last_visit).getTime() : 0;
          valB = b.last_visit ? new Date(b.last_visit).getTime() : 0;
          break;
        case 'absence':
          valA = a.days_since_last_visit || 0;
          valB = b.days_since_last_visit || 0;
          break;
        default:
          valA = (a as any)[sortConfig.key];
          valB = (b as any)[sortConfig.key];
      }

      if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
      if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [clients, searchQuery, sortConfig]);

  const SortIndicator = ({ column }: { column: SortConfig['key'] }) => {
    if (sortConfig.key !== column) return <ArrowUpDown size={12} className="ml-2 opacity-20" />;
    return sortConfig.direction === 'asc' ? <ChevronUp size={14} className="ml-2 text-primary-500" /> : <ChevronDown size={14} className="ml-2 text-primary-500" />;
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black text-zinc-900 dark:text-white tracking-tight uppercase">BASE DE CLIENTES</h1>
          <p className="text-zinc-500 dark:text-zinc-400 font-bold uppercase text-[10px] tracking-widest">Painel de recorrência e filtros inteligentes</p>
        </div>
      </div>

      {/* Busca */}
      <div className="bg-white dark:bg-zinc-900 p-2 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-primary-500 transition-colors" size={20} />
          <input 
            type="text" 
            value={searchQuery} 
            onChange={(e) => setSearchQuery(e.target.value)} 
            placeholder="Pesquisar por nome ou WhatsApp..." 
            className="w-full pl-12 pr-4 py-4 bg-transparent border-none text-zinc-900 dark:text-white font-medium outline-none placeholder:text-zinc-400" 
          />
        </div>
      </div>

      {/* Tabela Interativa (Spreadsheet Style) */}
      <div className="bg-white dark:bg-zinc-900 rounded-[32px] border border-zinc-200 dark:border-zinc-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-50 dark:bg-zinc-800/50 border-b border-zinc-100 dark:border-zinc-800">
                <th 
                  className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest cursor-pointer hover:text-zinc-900 dark:hover:text-white transition-colors"
                  onClick={() => handleSort('name')}
                >
                  <div className="flex items-center">Cliente <SortIndicator column="name" /></div>
                </th>
                <th 
                  className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest cursor-pointer hover:text-zinc-900 dark:hover:text-white transition-colors"
                  onClick={() => handleSort('risk_level')}
                >
                  <div className="flex items-center">Status de Risco <SortIndicator column="risk_level" /></div>
                </th>
                <th 
                  className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest cursor-pointer hover:text-zinc-900 dark:hover:text-white transition-colors"
                  onClick={() => handleSort('last_visit')}
                >
                  <div className="flex items-center">Última Visita <SortIndicator column="last_visit" /></div>
                </th>
                <th 
                  className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest cursor-pointer hover:text-zinc-900 dark:hover:text-white transition-colors"
                  onClick={() => handleSort('absence')}
                >
                  <div className="flex items-center">Ausência <SortIndicator column="absence" /></div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50 dark:divide-zinc-800/50">
              {filteredClients.map((client) => (
                <tr 
                  key={client.id} 
                  onClick={() => setEditingClient(client)}
                  className="hover:bg-zinc-50 dark:hover:bg-zinc-800/40 transition-all cursor-pointer group"
                >
                  <td className="px-8 py-5">
                    <div className="flex flex-col">
                      <span className="font-black text-zinc-900 dark:text-white uppercase text-sm tracking-tight group-hover:text-primary-500 transition-colors">{client.name}</span>
                      <span className="text-xs text-zinc-500 font-bold mt-0.5">{client.phone}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase border ${getRiskColor(client.risk_level)}`}>
                      {translateRisk(client.risk_level)}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center text-sm font-bold text-zinc-600 dark:text-zinc-400">
                      <Calendar size={14} className="mr-2 opacity-40" />
                      {client.last_visit ? new Date(client.last_visit).toLocaleDateString('pt-BR') : 'Sem registro'}
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center text-sm font-black text-zinc-900 dark:text-zinc-300">
                      <Clock size={14} className="mr-2 text-zinc-400" />
                      {client.days_since_last_visit} {client.days_since_last_visit === 1 ? 'dia' : 'dias'}
                    </div>
                  </td>
                </tr>
              ))}
              {filteredClients.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <p className="text-zinc-400 font-bold uppercase text-xs tracking-widest">Nenhum cliente encontrado</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {editingClient && (
        <EditClientModal 
          client={editingClient} 
          onClose={() => setEditingClient(null)} 
          onSave={handleSaveClient} 
        />
      )}
    </div>
  );
};

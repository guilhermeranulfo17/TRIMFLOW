
import React, { useState } from 'react';
import { Scissors, Clock, ArrowRight, CheckCircle2, Store, User, DollarSign, Trash2, Plus } from 'lucide-react';
import { BusinessConfig, Service } from '../types';
import { MOCK_SERVICES } from '../services/mockData';

interface OnboardingProps {
  onComplete: (config: BusinessConfig, services: Service[]) => void;
}

export const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [config, setConfig] = useState<BusinessConfig>({
    shopName: '',
    userName: '',
    openingTime: '09:00',
    closingTime: '19:00',
    lunchStart: '12:00',
    lunchEnd: '13:00',
    onboardingCompleted: true
  });

  const [services, setServices] = useState<Service[]>(MOCK_SERVICES);

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const updateService = (id: string, field: keyof Service, value: any) => {
    setServices(services.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const removeService = (id: string) => {
    setServices(services.filter(s => s.id !== id));
  };

  const addService = () => {
    const newService: Service = {
      id: `s-${Date.now()}`,
      name: 'Novo Serviço',
      price: 50,
      duration_minutes: 30,
      category: 'Cabelo'
    };
    setServices([...services, newService]);
  };

  return (
    <div className="fixed inset-0 bg-zinc-950 z-[100] flex items-center justify-center p-4 md:p-10 font-sans overflow-y-auto">
      <div className="max-w-2xl w-full my-auto">
        
        {/* Progress Bar */}
        <div className="flex gap-2 mb-12">
          {[1, 2, 3, 4].map(s => (
            <div key={s} className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${step >= s ? 'bg-primary-500' : 'bg-zinc-800'}`} />
          ))}
        </div>

        {step === 1 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="w-20 h-20 bg-primary-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-primary-500/20 mb-8">
               <Scissors size={40} className="text-white" />
            </div>
            <div className="space-y-2">
              <h1 className="text-4xl font-black text-white tracking-tight">Bem-vindo ao Trim Flow</h1>
              <p className="text-zinc-400 text-lg">Primeiro, como devemos chamar você e seu negócio?</p>
            </div>
            
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest">Seu Nome</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input 
                    autoFocus
                    type="text" 
                    value={config.userName}
                    onChange={e => setConfig({...config, userName: e.target.value})}
                    placeholder="Ex: João Silva"
                    className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl py-4 pl-12 pr-4 text-white text-xl focus:border-primary-500 outline-none transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest">Nome da Barbearia</label>
                <div className="relative">
                  <Store className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                  <input 
                    type="text" 
                    value={config.shopName}
                    onChange={e => setConfig({...config, shopName: e.target.value})}
                    placeholder="Ex: Barber Shop Premium"
                    className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl py-4 pl-12 pr-4 text-white text-xl focus:border-primary-500 outline-none transition-all"
                  />
                </div>
              </div>
            </div>

            <button 
              onClick={nextStep}
              disabled={!config.shopName || !config.userName}
              className="w-full bg-white text-zinc-950 py-4 rounded-2xl font-black text-lg flex items-center justify-center space-x-2 hover:bg-zinc-200 transition-all disabled:opacity-50"
            >
              <span>Continuar</span>
              <ArrowRight size={20} />
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="space-y-2">
              <h2 className="text-3xl font-black text-white tracking-tight">Horários de Operação</h2>
              <p className="text-zinc-400 text-lg">Quando a {config.shopName} recebe os clientes?</p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Abre às</label>
                <input 
                  type="time" 
                  value={config.openingTime}
                  onChange={e => setConfig({...config, openingTime: e.target.value})}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none focus:border-primary-500 text-xl"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Fecha às</label>
                <input 
                  type="time" 
                  value={config.closingTime}
                  onChange={e => setConfig({...config, closingTime: e.target.value})}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none focus:border-primary-500 text-xl"
                />
              </div>
            </div>

            <div className="bg-zinc-900/50 p-6 rounded-[32px] border border-zinc-800">
              <div className="flex items-center space-x-3 mb-4">
                 <Clock className="text-primary-500" size={20} />
                 <span className="font-bold text-white uppercase text-xs tracking-widest">Intervalo de Almoço</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <input 
                  type="time" 
                  value={config.lunchStart}
                  onChange={e => setConfig({...config, lunchStart: e.target.value})}
                  className="bg-zinc-800 border-none rounded-xl p-3 text-white text-sm outline-none font-bold"
                />
                 <input 
                  type="time" 
                  value={config.lunchEnd}
                  onChange={e => setConfig({...config, lunchEnd: e.target.value})}
                  className="bg-zinc-800 border-none rounded-xl p-3 text-white text-sm outline-none font-bold"
                />
              </div>
            </div>

            <div className="flex gap-4">
              <button onClick={prevStep} className="flex-1 py-4 text-zinc-500 font-black uppercase tracking-widest hover:text-white transition-colors">Voltar</button>
              <button onClick={nextStep} className="flex-[2] bg-primary-600 text-white py-4 rounded-2xl font-black text-lg flex items-center justify-center space-x-2 hover:bg-primary-700 transition-all shadow-xl shadow-primary-500/20">
                <span>Configurar Serviços</span>
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="space-y-2">
              <h2 className="text-3xl font-black text-white tracking-tight">Menu de Serviços</h2>
              <p className="text-zinc-400 text-lg">Defina seus serviços iniciais e preços.</p>
            </div>

            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {services.map((service) => (
                <div key={service.id} className="group bg-zinc-900 border border-zinc-800 p-5 rounded-3xl flex items-center gap-4 transition-all hover:border-zinc-700">
                   <div className="flex-1">
                      <input 
                        type="text" 
                        value={service.name} 
                        onChange={(e) => updateService(service.id, 'name', e.target.value)}
                        className="bg-transparent border-none text-white font-black uppercase text-sm outline-none w-full focus:text-primary-400"
                      />
                      <div className="flex items-center gap-3 mt-2">
                        <select 
                          value={service.duration_minutes}
                          onChange={(e) => updateService(service.id, 'duration_minutes', parseInt(e.target.value))}
                          className="bg-zinc-800 border-none text-[10px] font-black text-zinc-400 uppercase rounded-lg px-2 py-1 outline-none"
                        >
                          <option value={15}>15 min</option>
                          <option value={30}>30 min</option>
                          <option value={45}>45 min</option>
                          <option value={60}>60 min</option>
                          <option value={90}>90 min</option>
                        </select>
                        <select 
                          value={service.category}
                          onChange={(e) => updateService(service.id, 'category', e.target.value)}
                          className="bg-zinc-800 border-none text-[10px] font-black text-zinc-400 uppercase rounded-lg px-2 py-1 outline-none"
                        >
                          <option value="Cabelo">Cabelo</option>
                          <option value="Barba">Barba</option>
                          <option value="Estética">Estética</option>
                          <option value="Combo">Combo</option>
                        </select>
                      </div>
                   </div>
                   <div className="flex items-center gap-3">
                      <div className="relative">
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-bold">R$</span>
                        <input 
                          type="number" 
                          value={service.price} 
                          onChange={(e) => updateService(service.id, 'price', parseFloat(e.target.value))}
                          className="w-20 bg-zinc-800 border-none rounded-xl py-2 pl-7 pr-2 text-white text-sm font-black outline-none"
                        />
                      </div>
                      <button 
                        onClick={() => removeService(service.id)}
                        className="p-2 text-zinc-600 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                   </div>
                </div>
              ))}
              <button 
                onClick={addService}
                className="w-full py-4 border-2 border-dashed border-zinc-800 rounded-3xl text-zinc-500 flex items-center justify-center gap-2 hover:border-zinc-600 hover:text-zinc-300 transition-all"
              >
                <Plus size={18} />
                <span className="font-black uppercase text-xs tracking-widest">Adicionar mais um</span>
              </button>
            </div>

            <div className="flex gap-4">
              <button onClick={prevStep} className="flex-1 py-4 text-zinc-500 font-black uppercase tracking-widest hover:text-white transition-colors">Voltar</button>
              <button onClick={nextStep} className="flex-[2] bg-emerald-600 text-white py-4 rounded-2xl font-black text-lg flex items-center justify-center space-x-2 hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-500/20">
                <span>Finalizar</span>
                <CheckCircle2 size={20} />
              </button>
            </div>
          </div>
        )}

        {step === 4 && (
           <div className="text-center space-y-8 animate-in zoom-in duration-500">
              <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/20">
                 <CheckCircle2 size={48} className="text-white" />
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Parabéns, {config.userName.split(' ')[0]}!</h2>
                <p className="text-zinc-400 text-lg">A {config.shopName} está pronta para voar alto.</p>
              </div>
              <button 
                onClick={() => onComplete(config, services)}
                className="w-full bg-white text-zinc-950 py-5 rounded-3xl font-black text-xl hover:bg-zinc-200 transition-all shadow-2xl shadow-white/5"
              >
                Acessar meu Dashboard
              </button>
           </div>
        )}
      </div>
    </div>
  );
};


import React, { useState, useRef, useEffect } from 'react';
import { MOCK_SERVICES } from '../services/mockData';
import { Clock, Plus, Edit2, GripVertical, Trash2, X, Save, Tag } from 'lucide-react';
import { Service } from '../types';

const ServiceModal = ({ 
  service, 
  onClose, 
  onSave 
}: { 
  service: Service | null, 
  onClose: () => void, 
  onSave: (s: Service) => void 
}) => {
  const [formData, setFormData] = useState<Service>(service || {
    id: `s-${Date.now()}`,
    name: '',
    price: 0,
    duration_minutes: 30,
    category: 'Cabelo'
  });

  const DURATIONS = [15, 30, 45, 60, 90, 120];
  const CATEGORIES = ['Cabelo', 'Barba', 'Estética', 'Combo', 'Outros'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-zinc-900 rounded-[40px] shadow-2xl w-full max-w-lg overflow-hidden border border-zinc-200 dark:border-zinc-800">
        <div className="px-10 py-8 border-b border-zinc-100 dark:border-zinc-800 flex justify-between items-center bg-zinc-50/50 dark:bg-zinc-900/50">
          <h3 className="font-black text-2xl text-zinc-900 dark:text-white uppercase tracking-tighter">
            {service ? 'Editar Serviço' : 'Novo Serviço'}
          </h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 transition-colors"><X size={28} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-10 space-y-8">
          <div className="space-y-6">
            <div>
              <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3">Nome do Serviço</label>
              <input 
                autoFocus
                type="text" 
                value={formData.name} 
                onChange={e => setFormData({...formData, name: e.target.value})} 
                placeholder="Ex: Corte Degradê Premium"
                className="w-full px-6 py-4 bg-zinc-100 dark:bg-zinc-800 border-none rounded-2xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none font-bold" 
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3">Preço (R$)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-bold">R$</span>
                  <input 
                    type="number" 
                    value={formData.price} 
                    onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} 
                    className="w-full pl-12 pr-4 py-4 bg-zinc-100 dark:bg-zinc-800 border-none rounded-2xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none font-black" 
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3">Categoria</label>
                <select 
                  value={formData.category}
                  onChange={e => setFormData({...formData, category: e.target.value})}
                  className="w-full px-6 py-4 bg-zinc-100 dark:bg-zinc-800 border-none rounded-2xl text-zinc-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none font-bold appearance-none"
                >
                  {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3 flex justify-between">
                Duração (Minutos) <span>{formData.duration_minutes} min</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                {DURATIONS.map(time => (
                  <button 
                    key={time}
                    type="button"
                    onClick={() => setFormData({...formData, duration_minutes: time})}
                    className={`py-3 rounded-xl text-xs font-black uppercase transition-all ${formData.duration_minutes === time ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/20' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500 hover:bg-zinc-200 dark:hover:bg-zinc-700'}`}
                  >
                    {time} min
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-5 text-sm font-black text-zinc-400 uppercase tracking-widest hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors">Descartar</button>
            <button type="submit" className="flex-[2] py-5 text-sm font-black text-white bg-zinc-900 dark:bg-white dark:text-zinc-900 rounded-3xl shadow-xl flex items-center justify-center uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all">
              <Save size={20} className="mr-3" />
              {service ? 'Salvar Alterações' : 'Criar Serviço'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const Services = () => {
  const [services, setServices] = useState<Service[]>(() => {
    const savedOrder = localStorage.getItem('trendflow_services_order');
    return savedOrder ? JSON.parse(savedOrder) : MOCK_SERVICES;
  });

  const [modalOpen, setModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);

  const dragItem = useRef<number | null>(null);

  useEffect(() => {
    localStorage.setItem('trendflow_services_order', JSON.stringify(services));
  }, [services]);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, position: number) => {
    dragItem.current = position;
    e.dataTransfer.effectAllowed = "move";
    e.currentTarget.classList.add('opacity-50', 'scale-95');
  };

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, position: number) => {
    e.preventDefault();
    if (dragItem.current === null || dragItem.current === position) return;

    const newList = [...services];
    const draggedItemContent = newList[dragItem.current];
    newList.splice(dragItem.current, 1);
    newList.splice(position, 0, draggedItemContent);
    dragItem.current = position;
    setServices(newList);
  };

  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
    e.currentTarget.classList.remove('opacity-50', 'scale-95');
    dragItem.current = null;
  };

  const handleSave = (serviceData: Service) => {
    if (editingService) {
      setServices(services.map(s => s.id === serviceData.id ? serviceData : s));
    } else {
      setServices([...services, serviceData]);
    }
    setModalOpen(false);
    setEditingService(null);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Tem certeza que deseja remover este serviço?')) {
      setServices(services.filter(s => s.id !== id));
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-zinc-900 dark:text-white tracking-tighter uppercase">MENU DE SERVIÇOS</h1>
          <p className="text-zinc-500 dark:text-zinc-400 font-bold uppercase text-[10px] tracking-[0.2em] mt-2">Personalize sua oferta e organize a ordem de exibição</p>
        </div>
        <button 
          onClick={() => { setEditingService(null); setModalOpen(true); }}
          className="bg-zinc-900 hover:bg-zinc-800 dark:bg-white dark:hover:bg-zinc-200 text-white dark:text-zinc-900 px-8 py-4 rounded-3xl font-black text-xs uppercase tracking-widest flex items-center shadow-2xl shadow-zinc-900/20 dark:shadow-white/5 transition-all hover:-translate-y-1 active:scale-95"
        >
          <Plus size={20} className="mr-3" />
          Novo Serviço
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service, index) => (
          <div 
            key={service.id}
            draggable
            onDragStart={(e) => handleDragStart(e, index)}
            onDragEnter={(e) => handleDragEnter(e, index)}
            onDragEnd={handleDragEnd}
            onDragOver={(e) => e.preventDefault()}
            onClick={() => { setEditingService(service); setModalOpen(true); }}
            className="group relative bg-white dark:bg-zinc-900 rounded-[40px] p-8 border border-zinc-200 dark:border-zinc-800 shadow-sm hover:shadow-2xl hover:border-primary-500/50 transition-all cursor-pointer active:cursor-grabbing overflow-hidden"
          >
             {/* Header Info */}
             <div className="flex justify-between items-start mb-6">
                <span className="flex items-center px-3 py-1 rounded-full text-[9px] font-black bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 uppercase tracking-widest border border-zinc-200/50 dark:border-zinc-700/50">
                   <Tag size={10} className="mr-1.5 opacity-50" /> {service.category}
                </span>
                <div className="flex gap-2">
                   <button 
                    onClick={(e) => handleDelete(service.id, e)}
                    className="p-2 text-zinc-300 hover:text-red-500 transition-colors"
                   >
                     <Trash2 size={16} />
                   </button>
                   <div className="p-2 text-zinc-300 dark:text-zinc-600">
                     <GripVertical size={20} />
                   </div>
                </div>
             </div>
             
             <h3 className="text-2xl font-black text-zinc-900 dark:text-white uppercase tracking-tight group-hover:text-primary-500 transition-colors">{service.name}</h3>
             
             {/* Stats */}
             <div className="flex items-end justify-between mt-10">
                <div>
                   <p className="text-[9px] text-zinc-400 uppercase font-black tracking-widest mb-1.5 opacity-60">Valor do Investimento</p>
                   <p className="text-3xl font-black text-zinc-900 dark:text-white tracking-tighter">
                    <span className="text-sm font-bold mr-1 opacity-40">R$</span>
                    {service.price.toFixed(2)}
                   </p>
                </div>
                <div className="text-right">
                   <p className="text-[9px] text-zinc-400 uppercase font-black tracking-widest mb-1.5 opacity-60">Duração</p>
                   <p className="flex items-center justify-end text-sm font-black text-zinc-900 dark:text-zinc-300 uppercase tracking-tighter">
                      <Clock size={16} className="mr-2 text-primary-500" />
                      {service.duration_minutes} min
                   </p>
                </div>
             </div>

             {/* Hover Decorative Element */}
             <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-primary-500/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
        
        {/* Empty State / Add New Card */}
        <div 
          onClick={() => { setEditingService(null); setModalOpen(true); }}
          className="border-4 border-dashed border-zinc-100 dark:border-zinc-800/50 rounded-[40px] p-8 flex flex-col items-center justify-center text-zinc-300 dark:text-zinc-700 hover:border-primary-500/50 hover:text-primary-500 dark:hover:text-primary-400 hover:bg-zinc-50 dark:hover:bg-primary-950/10 cursor-pointer transition-all min-h-[220px]"
        >
           <Plus size={48} strokeWidth={3} className="mb-4 opacity-20" />
           <span className="font-black uppercase text-xs tracking-[0.25em]">Adicionar Serviço</span>
        </div>
      </div>

      {modalOpen && (
        <ServiceModal 
          service={editingService} 
          onClose={() => setModalOpen(false)} 
          onSave={handleSave} 
        />
      )}
    </div>
  );
};

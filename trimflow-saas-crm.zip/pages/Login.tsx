
import React, { useState } from 'react';
import { 
  Scissors, 
  Mail, 
  Lock, 
  ArrowRight, 
  X, 
  Check, 
  Loader2, 
  Eye, 
  EyeOff, 
  MailOpen, 
  Send,
  ShieldCheck,
  BellRing,
  UserPlus,
  LogIn,
  ChevronLeft
} from 'lucide-react';
import { UserAccount } from '../types';

interface LoginProps {
  onLogin: (email: string, pass: string) => boolean;
  onRegister: (name: string, email: string, pass: string) => UserAccount;
  onVerify: (user: UserAccount) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin, onRegister, onVerify }) => {
  const [view, setView] = useState<'selection' | 'login' | 'register' | 'verifying'>('selection');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const [pendingUser, setPendingUser] = useState<UserAccount | null>(null);
  const [showEmailNotification, setShowEmailNotification] = useState(false);
  const [isEmailOpened, setIsEmailOpened] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    setTimeout(() => {
      if (view === 'register') {
        const newUser = onRegister(name, email, password);
        setPendingUser(newUser);
        setView('verifying');
        setIsLoading(false);
        // Notificação de e-mail aparece após o envio simulado
        setTimeout(() => setShowEmailNotification(true), 2000);
      } else {
        const success = onLogin(email, password);
        if (!success) {
          setError("Credenciais inválidas ou conta não verificada.");
          setIsLoading(false);
        }
      }
    }, 1200);
  };

  const handleVerifyEmail = () => {
    setIsEmailOpened(true);
    setIsLoading(true);
    setTimeout(() => {
      if (pendingUser) {
        onVerify(pendingUser);
        // Após verificar, o App.tsx já deve redirecionar, mas aqui limpamos o estado local
      }
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-zinc-950 flex flex-col items-center justify-center p-6 overflow-hidden">
      {/* Background Cinético */}
      <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-primary-600/10 blur-[150px] rounded-full animate-pulse" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-emerald-600/10 blur-[150px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />

      {/* Push Notification Simulada */}
      {showEmailNotification && !isEmailOpened && (
        <div className="fixed top-8 right-8 z-[200] animate-in slide-in-from-right-8 duration-500">
           <div 
             onClick={() => setIsEmailOpened(true)}
             className="bg-white rounded-[28px] p-5 shadow-2xl flex items-center gap-4 border border-zinc-200 cursor-pointer hover:scale-105 transition-all group active:scale-95"
           >
              <div className="bg-zinc-900 text-white p-3 rounded-2xl group-hover:bg-primary-500 transition-colors">
                <BellRing size={20} className="animate-ring" />
              </div>
              <div className="pr-4">
                <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Trim Flow • Agora</p>
                <p className="text-sm font-bold text-zinc-900">Validar seu Acesso</p>
                <p className="text-[10px] text-zinc-500 font-medium">Clique para confirmar seu e-mail.</p>
              </div>
           </div>
        </div>
      )}

      {/* Modal de E-mail Simulado */}
      {isEmailOpened && (
        <div className="fixed inset-0 bg-zinc-950/90 backdrop-blur-2xl z-[250] flex items-center justify-center p-4">
           <div className="bg-white rounded-[48px] w-full max-w-lg overflow-hidden shadow-2xl animate-in zoom-in-95 duration-500">
              <div className="bg-zinc-50 px-8 py-6 border-b border-zinc-100 flex justify-between items-center">
                 <div className="flex items-center gap-3">
                   <div className="bg-zinc-900 p-2 rounded-xl text-white"><MailOpen size={18} /></div>
                   <span className="text-zinc-900 font-black uppercase text-[10px] tracking-widest">Confirmação de Segurança</span>
                 </div>
                 <button onClick={() => setIsEmailOpened(false)} className="text-zinc-400 hover:text-zinc-900 transition-colors"><X size={20} /></button>
              </div>
              <div className="p-12 text-center space-y-8">
                 <div className="w-24 h-24 bg-primary-500/10 rounded-full flex items-center justify-center mx-auto ring-8 ring-primary-500/5">
                    <ShieldCheck className="text-primary-600" size={48} />
                 </div>
                 <div>
                    <h3 className="text-3xl font-black text-zinc-900 uppercase tracking-tight italic">Quase lá, {pendingUser?.name.split(' ')[0]}!</h3>
                    <p className="text-zinc-500 mt-3 text-lg leading-relaxed">Sua conta foi criada com sucesso. Para começar a gerir sua barbearia, confirme sua identidade no botão abaixo.</p>
                 </div>
                 <div className="space-y-4">
                    <button 
                      onClick={handleVerifyEmail}
                      disabled={isLoading}
                      className="w-full bg-zinc-900 text-white py-6 rounded-3xl font-black uppercase tracking-widest text-sm flex items-center justify-center gap-3 hover:shadow-2xl hover:bg-zinc-800 transition-all active:scale-95 disabled:opacity-50"
                    >
                        {isLoading ? <Loader2 className="animate-spin" /> : <><Check size={20} /> Validar Agora</>}
                    </button>
                    <p className="text-[9px] text-zinc-400 font-bold uppercase tracking-widest">Proteção de Dados SSL Ativa</p>
                 </div>
              </div>
           </div>
        </div>
      )}

      <div className="w-full max-w-5xl space-y-12 relative z-10">
        {/* Logo Section */}
        <div className="text-center space-y-4 animate-in fade-in slide-in-from-top-4 duration-1000">
          <div className="w-20 h-20 bg-white rounded-[32px] flex items-center justify-center shadow-2xl mx-auto rotate-6 group transition-all hover:rotate-0 cursor-pointer hover:shadow-primary-500/20">
            <Scissors className="text-zinc-950 group-hover:scale-110 transition-transform" size={40} />
          </div>
          <h1 className="text-5xl font-black text-white tracking-tighter uppercase italic">TRIM FLOW</h1>
          <p className="text-zinc-500 font-bold uppercase text-[10px] tracking-[0.4em]">SISTEMA DE GESTÃO DE ALTO NÍVEL</p>
        </div>

        {view === 'selection' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in zoom-in-95 duration-500">
            {/* Card Primeiro Acesso */}
            <button 
              onClick={() => setView('register')}
              className="group bg-zinc-900/40 backdrop-blur-3xl border-2 border-white/5 p-12 rounded-[56px] text-left hover:border-primary-500/50 hover:bg-zinc-900/60 transition-all hover:-translate-y-2"
            >
              <div className="w-16 h-16 bg-primary-500/20 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                <UserPlus className="text-primary-500" size={32} />
              </div>
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Primeiro Acesso</h2>
              <p className="text-zinc-500 font-medium leading-relaxed">Inicie sua jornada no CRM. Configure sua barbearia e comece a escalar hoje mesmo.</p>
              <div className="mt-10 flex items-center text-primary-500 font-black uppercase text-xs tracking-widest gap-2">
                <span>Começar Agora</span>
                <ArrowRight size={16} />
              </div>
            </button>

            {/* Card Login */}
            <button 
              onClick={() => setView('login')}
              className="group bg-white/5 backdrop-blur-3xl border-2 border-white/5 p-12 rounded-[56px] text-left hover:border-white/20 hover:bg-white/10 transition-all hover:-translate-y-2"
            >
              <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                <LogIn className="text-zinc-900" size={32} />
              </div>
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Já sou de casa</h2>
              <p className="text-zinc-500 font-medium leading-relaxed">Acesse seu terminal de gestão. Seus dados e clientes estão seguros e esperando por você.</p>
              <div className="mt-10 flex items-center text-white font-black uppercase text-xs tracking-widest gap-2">
                <span>Fazer Login</span>
                <ArrowRight size={16} />
              </div>
            </button>
          </div>
        ) : (
          <div className="max-w-md mx-auto w-full">
            <div className="bg-zinc-900/50 backdrop-blur-3xl border border-white/10 p-12 rounded-[56px] shadow-2xl relative overflow-hidden transition-all duration-500">
              <button 
                onClick={() => setView('selection')}
                className="absolute left-8 top-8 text-zinc-500 hover:text-white transition-colors flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
              >
                <ChevronLeft size={16} /> Voltar
              </button>

              {view === 'verifying' ? (
                <div className="py-12 text-center space-y-10 animate-in zoom-in-95 duration-700">
                   <div className="w-28 h-28 bg-primary-500/20 rounded-[40px] flex items-center justify-center mx-auto relative">
                      <Send className="text-primary-500 animate-bounce" size={48} />
                   </div>
                   <div className="space-y-3">
                     <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Valide sua Identidade</h2>
                     <p className="text-zinc-400 text-base leading-relaxed">
                       Enviamos um código de segurança para:<br/>
                       <span className="text-primary-400 font-bold">{email}</span>
                     </p>
                   </div>
                   <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                      <div className="flex items-center justify-center gap-3 text-zinc-500 text-[10px] font-black uppercase tracking-[0.25em]">
                         <Loader2 size={16} className="animate-spin text-primary-500" />
                         Sincronizando...
                      </div>
                   </div>
                </div>
              ) : (
                <div className="pt-8">
                  <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-8 text-center italic">
                    {view === 'register' ? 'Nova Licença' : 'Terminal Seguro'}
                  </h2>

                  {error && (
                    <div className="mb-8 p-5 bg-red-500/10 border border-red-500/20 rounded-[24px] flex items-center gap-4 text-red-500 text-[11px] font-black uppercase tracking-widest animate-in slide-in-from-top-4">
                      <X size={18} />
                      {error}
                    </div>
                  )}

                  <form onSubmit={handleSubmit} className="space-y-7">
                    {view === 'register' && (
                      <div className="space-y-2 animate-in slide-in-from-top-4 duration-300">
                        <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest ml-2">Nome do Gestor</label>
                        <input 
                          type="text" 
                          required 
                          value={name}
                          onChange={e => setName(e.target.value)}
                          placeholder="Ex: João da Silva"
                          className="w-full bg-white/5 border border-white/10 rounded-3xl py-5 px-6 text-white focus:border-primary-500 outline-none transition-all placeholder:text-zinc-700 font-bold text-lg"
                        />
                      </div>
                    )}

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest ml-2">E-mail Corporativo</label>
                      <div className="relative group">
                        <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-primary-500 transition-colors" size={20} />
                        <input 
                          type="email" 
                          required 
                          value={email}
                          onChange={e => setEmail(e.target.value)}
                          placeholder="admin@barber.com"
                          className="w-full bg-white/5 border border-white/10 rounded-3xl py-5 pl-16 pr-6 text-white focus:border-primary-500 outline-none transition-all placeholder:text-zinc-700 font-bold text-lg"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest ml-2">Senha de Acesso</label>
                      <div className="relative group">
                        <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-primary-500 transition-colors" size={20} />
                        <input 
                          type={showPassword ? "text" : "password"} 
                          required 
                          value={password}
                          onChange={e => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-3xl py-5 pl-16 pr-16 text-white focus:border-primary-500 outline-none transition-all placeholder:text-zinc-700 font-bold text-lg"
                        />
                        <button 
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-6 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-white transition-colors"
                        >
                          {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                    </div>

                    <button 
                      type="submit" 
                      disabled={isLoading}
                      className="w-full bg-white text-zinc-950 font-black py-6 rounded-[32px] shadow-2xl hover:bg-zinc-200 transition-all flex items-center justify-center space-x-3 mt-6 active:scale-95 disabled:opacity-50"
                    >
                      {isLoading ? (
                        <Loader2 size={24} className="animate-spin" />
                      ) : (
                        <>
                          <span className="uppercase tracking-widest text-sm">{view === 'register' ? 'Ativar Licença' : 'Desbloquear'}</span>
                          <ArrowRight size={20} />
                        </>
                      )}
                    </button>
                  </form>

                  <div className="mt-10 text-center">
                    <button 
                      onClick={() => {
                        setView(view === 'register' ? 'login' : 'register');
                        setError(null);
                      }}
                      className="text-zinc-500 text-[10px] font-black uppercase tracking-widest hover:text-white transition-all"
                    >
                      {view === 'register' ? 'Já sou de casa? Fazer Login' : 'Novo por aqui? Criar Minha Empresa'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        <div className="text-center opacity-30 mt-12 flex flex-col items-center gap-2">
          <p className="text-[9px] font-black text-zinc-400 uppercase tracking-[0.5em]">Trim Flow • SaaS Business Intelligence v2.5</p>
          <div className="flex gap-4">
             <div className="w-1.5 h-1.5 bg-primary-500 rounded-full"></div>
             <div className="w-1.5 h-1.5 bg-zinc-800 rounded-full"></div>
             <div className="w-1.5 h-1.5 bg-zinc-800 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

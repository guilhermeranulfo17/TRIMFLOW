
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Appointments } from './pages/Appointments';
import { Recovery } from './pages/Recovery';
import { Clients } from './pages/Clients';
import { Services } from './pages/Services';
import { Settings } from './pages/Settings';
import { Reports } from './pages/Reports';
import { Onboarding } from './pages/Onboarding';
import { Login } from './pages/Login';
import { BusinessConfig, Service, UserAccount } from './types';

function App() {
  const [user, setUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('trimflow_session');
    return saved ? JSON.parse(saved) : null;
  });

  const [config, setConfig] = useState<BusinessConfig | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user && user.verified) {
      const savedConfig = localStorage.getItem(`trimflow_config_${user.id}`);
      if (savedConfig) {
        setConfig(JSON.parse(savedConfig));
      } else {
        setConfig(null);
      }
    } else {
      setConfig(null);
    }
    setLoading(false);
  }, [user]);

  const handleLogin = (email: string, pass: string): boolean => {
    const users: UserAccount[] = JSON.parse(localStorage.getItem('trimflow_users') || '[]');
    const found = users.find(u => u.email === email && u.password === pass);
    
    if (found) {
      if (!found.verified) {
        alert("Por favor, verifique seu e-mail antes de entrar.");
        return false;
      }
      localStorage.setItem('trimflow_session', JSON.stringify(found));
      setUser(found);
      return true;
    }
    return false;
  };

  const handleRegister = (name: string, email: string, pass: string): UserAccount => {
    const users: UserAccount[] = JSON.parse(localStorage.getItem('trimflow_users') || '[]');
    
    const newUser: UserAccount = {
      id: `u-${Date.now()}`,
      name,
      email,
      password: pass,
      onboardingCompleted: false,
      verified: false // Inicia não verificado
    };

    localStorage.setItem('trimflow_users', JSON.stringify([...users, newUser]));
    return newUser;
  };

  const handleVerifySuccess = (verifiedUser: UserAccount) => {
    const users: UserAccount[] = JSON.parse(localStorage.getItem('trimflow_users') || '[]');
    const updatedUser = { ...verifiedUser, verified: true };
    localStorage.setItem('trimflow_users', JSON.stringify(users.map(u => u.id === verifiedUser.id ? updatedUser : u)));
    localStorage.setItem('trimflow_session', JSON.stringify(updatedUser));
    setUser(updatedUser);
  };

  const handleLogout = () => {
    localStorage.removeItem('trimflow_session');
    setUser(null);
  };

  const handleCompleteOnboarding = (newConfig: BusinessConfig, services: Service[]) => {
    if (!user) return;
    
    localStorage.setItem(`trimflow_config_${user.id}`, JSON.stringify(newConfig));
    localStorage.setItem(`trimflow_services_${user.id}`, JSON.stringify(services));
    
    const updatedUser = { ...user, onboardingCompleted: true };
    const users: UserAccount[] = JSON.parse(localStorage.getItem('trimflow_users') || '[]');
    localStorage.setItem('trimflow_users', JSON.stringify(users.map(u => u.id === user.id ? updatedUser : u)));
    localStorage.setItem('trimflow_session', JSON.stringify(updatedUser));
    
    setUser(updatedUser);
    setConfig(newConfig);
  };

  if (loading) return null;

  if (!user || !user.verified) {
    return <Login onLogin={handleLogin} onRegister={handleRegister} onVerify={handleVerifySuccess} />;
  }

  if (!user.onboardingCompleted || !config) {
    return <Onboarding onComplete={handleCompleteOnboarding} />;
  }

  return (
    <HashRouter>
      <Layout onLogout={handleLogout}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/clients" element={<Clients />} />
          <Route path="/recovery" element={<Recovery />} />
          <Route path="/services" element={<Services />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
}

export default App;


export enum RiskLevel {
  None = 'none',
  Light = 'light',
  Moderate = 'moderate',
  Critical = 'critical'
}

export enum TrendDirection {
  Improving = 'improving',
  Stable = 'stable',
  Declining = 'declining'
}

export enum AppointmentStatus {
  Scheduled = 'scheduled',
  Confirmed = 'confirmed',
  Completed = 'completed',
  Cancelled = 'cancelled',
  NoShow = 'no-show'
}

export interface UserAccount {
  id: string;
  email: string;
  password?: string;
  name: string;
  onboardingCompleted: boolean;
  verified: boolean;
  avatarUrl?: string;
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  email?: string;
  last_visit?: string;
  total_visits: number;
  average_service_value: number;
  average_frequency_days: number;
  is_inactive: boolean;
  days_since_last_visit: number;
  risk_level: RiskLevel;
  risk_percentage: number;
  trend_direction: TrendDirection;
  preferred_service?: string;
  avatar_url?: string;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  duration_minutes: number;
  category: string;
}

export interface Appointment {
  id: string;
  client_id: string;
  service_id: string;
  barber_id: string;
  service_name: string;
  appointment_date: string;
  appointment_time: string;
  duration_minutes: number;
  price: number;
  status: AppointmentStatus;
  client_name?: string;
}

export interface DashboardStats {
  revenue_today: number;
  revenue_month: number;
  appointments_today: number;
  active_clients: number;
  risk_clients_critical: number;
}

export interface BusinessConfig {
  shopName: string;
  userName: string;
  openingTime: string;
  closingTime: string;
  lunchStart: string;
  lunchEnd: string;
  onboardingCompleted: boolean;
}
